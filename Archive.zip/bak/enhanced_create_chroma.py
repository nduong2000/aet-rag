# Enhanced create_chroma_db.py for medical data dictionary
# Optimized for numbered definitions and embedded content including XLS tables

import os
import shutil
import re
from pathlib import Path
from langchain_community.document_loaders import (
    UnstructuredExcelLoader, 
    TextLoader,
    UnstructuredWordDocumentLoader,
    PyPDFLoader
)
from langchain_unstructured import UnstructuredLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_google_vertexai import VertexAIEmbeddings
from langchain.schema import Document
import chromadb
import logging
import json
from typing import List, Dict, Any, Optional, Tuple
import pandas as pd

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Configuration
DOCUMENTS_DIR = "./documents" 
CHROMA_DB_DIR = "./chroma_db_data"
COLLECTION_NAME = "rag_collection"
EMBEDDING_MODEL_NAME = "text-embedding-005"

# Enhanced chunking for complete numbered definitions
CHUNK_SIZE = 2000  # Increased for complete definitions
CHUNK_OVERLAP = 400  # Substantial overlap for context preservation
MIN_DEFINITION_SIZE = 50  # Minimum size for definition chunks

# Initialize Vertex AI Embeddings
try:
    embeddings = VertexAIEmbeddings(model_name=EMBEDDING_MODEL_NAME)
    logger.info(f"Successfully initialized VertexAIEmbeddings: {EMBEDDING_MODEL_NAME}")
except Exception as e:
    logger.error(f"Error initializing VertexAIEmbeddings: {e}")
    logger.info("Please ensure Google Cloud authentication and Vertex AI API access")
    exit(1)

def preprocess_text(text_content: str) -> str:
    """Enhanced text preprocessing for medical documentation"""
    if not text_content:
        return ""
    
    # Remove extra whitespace but preserve structure
    text_content = re.sub(r' +', ' ', text_content)
    text_content = re.sub(r'\n\s*\n\s*\n+', '\n\n', text_content)
    
    # Clean non-printable characters but keep medical symbols
    text_content = re.sub(r'[^\x20-\x7E\n\r\t]', ' ', text_content)
    
    # Fix common OCR/extraction issues
    text_content = re.sub(r'(\d+)\s*\.\s*([A-Z])', r'\1. \2', text_content)  # Fix numbered definitions
    text_content = re.sub(r'([a-z])\s*:\s*([A-Z])', r'\1: \2', text_content)  # Fix field separators
    
    return text_content.strip()

def detect_numbered_definition_boundaries(text: str) -> List[Tuple[int, int, str]]:
    """Detect numbered definition boundaries for optimal chunking"""
    boundaries = []
    
    # Pattern for numbered definitions (e.g., "141. HCFA Admit Type Code:")
    pattern = r'(\d+)\.\s*([^:\n]+):'
    matches = list(re.finditer(pattern, text))
    
    for i, match in enumerate(matches):
        start_pos = match.start()
        definition_number = match.group(1)
        definition_title = match.group(2).strip()
        
        # Find the end of this definition (start of next definition or end of text)
        if i + 1 < len(matches):
            end_pos = matches[i + 1].start()
        else:
            end_pos = len(text)
        
        boundaries.append((start_pos, end_pos, f"{definition_number}. {definition_title}"))
    
    return boundaries

def extract_embedded_tables(content: str) -> List[Dict]:
    """Extract embedded table content and value mappings"""
    tables = []
    
    # Pattern 1: Value mapping tables (Code = Description format)
    value_pattern = r'([A-Z0-9]+)\s*=\s*([^\n]+)'
    value_matches = re.findall(value_pattern, content)
    
    if value_matches:
        table_data = {
            'type': 'value_mapping',
            'data': value_matches,
            'formatted_content': '\n'.join([f"{code} = {desc}" for code, desc in value_matches])
        }
        tables.append(table_data)
    
    # Pattern 2: Field specification tables
    field_specs = re.findall(r'(Format|Technical Name|Length|Position[s]?):\s*([^\n]+)', content)
    if field_specs:
        table_data = {
            'type': 'field_specification',
            'data': field_specs,
            'formatted_content': '\n'.join([f"{field}: {value}" for field, value in field_specs])
        }
        tables.append(table_data)
    
    # Pattern 3: Structured appendix tables
    if 'appendix' in content.lower() or 'values and definitions' in content.lower():
        # Extract table-like structures
        lines = content.split('\n')
        table_lines = []
        in_table = False
        
        for line in lines:
            # Detect table headers or structured content
            if re.match(r'^[A-Z][a-z]+\s+[A-Z][a-z]+', line) or '|' in line:
                in_table = True
                table_lines.append(line)
            elif in_table and (line.strip() == '' or re.match(r'^\d+\.', line)):
                if table_lines:
                    tables.append({
                        'type': 'appendix_table',
                        'data': table_lines,
                        'formatted_content': '\n'.join(table_lines)
                    })
                    table_lines = []
                in_table = False
            elif in_table:
                table_lines.append(line)
        
        # Don't forget the last table
        if table_lines:
            tables.append({
                'type': 'appendix_table',
                'data': table_lines,
                'formatted_content': '\n'.join(table_lines)
            })
    
    return tables

def analyze_content_patterns(text: str) -> Dict[str, Any]:
    """Comprehensive analysis of content patterns"""
    patterns = {}
    
    # Numbered definitions
    numbered_defs = re.findall(r'(\d+)\.\s*([^:\n]+):', text)
    patterns['numbered_definitions'] = numbered_defs
    patterns['definition_count'] = len(numbered_defs)
    
    # Field specifications
    field_specs = re.findall(r'Technical Name:\s*([A-Z_][A-Z0-9_]*)', text)
    patterns['technical_names'] = field_specs
    
    # Data types and formats
    formats = re.findall(r'Format:\s*([^\n]+)', text)
    patterns['formats'] = formats
    
    # Lengths and positions
    lengths = re.findall(r'Length:\s*(\d+(?:\.\d+)?)', text)
    positions = re.findall(r'Position[s]?:\s*([\d\s\-]+)', text)
    patterns['lengths'] = lengths
    patterns['positions'] = positions
    
    # Value definitions
    values = re.findall(r'([A-Z0-9]+)\s*=\s*([^\n]+)', text)
    patterns['value_mappings'] = values
    
    # Cross-references
    field_refs = re.findall(r'[Ff]ield\s*#?\s*(\d+)', text)
    appendix_refs = re.findall(r'[Aa]ppendix|[Aa]ppendices', text)
    patterns['field_references'] = field_refs
    patterns['has_appendix_refs'] = len(appendix_refs) > 0
    
    # Content classification
    if numbered_defs:
        patterns['content_type'] = 'numbered_definition'
    elif field_specs:
        patterns['content_type'] = 'field_specification'
    elif values:
        patterns['content_type'] = 'value_mapping'
    elif any(keyword in text.lower() for keyword in ['appendix', 'values and definitions']):
        patterns['content_type'] = 'appendix'
    else:
        patterns['content_type'] = 'descriptive_text'
    
    return patterns

def create_enhanced_metadata(doc: Document, patterns: Dict, tables: List[Dict], file_path: str) -> Dict:
    """Create comprehensive metadata for ChromaDB"""
    metadata = {
        'source_filename': os.path.basename(file_path),
        'content_length': len(doc.page_content),
        'content_type': patterns.get('content_type', 'unknown'),
    }
    
    # Add file-specific metadata from original document
    if hasattr(doc, 'metadata') and doc.metadata:
        metadata.update({
            'page_number': str(doc.metadata.get('page_number', 'N/A')),
            'element_type': doc.metadata.get('category', 'Unknown'),
        })
    else:
        metadata.update({
            'page_number': 'N/A',
            'element_type': 'Unknown',
        })
    
    # Numbered definition metadata
    numbered_defs = patterns.get('numbered_definitions', [])
    if numbered_defs:
        metadata['definition_numbers'] = ','.join([num for num, _ in numbered_defs])
        metadata['definition_titles'] = ','.join([title for _, title in numbered_defs])
        metadata['is_numbered_definition'] = True
        
        # If single definition, add specific metadata
        if len(numbered_defs) == 1:
            metadata['definition_number'] = numbered_defs[0][0]
            metadata['definition_title'] = numbered_defs[0][1]
    else:
        metadata['is_numbered_definition'] = False
    
    # Field specification metadata
    technical_names = patterns.get('technical_names', [])
    if technical_names:
        metadata['technical_names'] = ','.join(technical_names)
        metadata['is_field_spec'] = True
        if len(technical_names) == 1:
            metadata['primary_technical_name'] = technical_names[0]
    else:
        metadata['is_field_spec'] = False
    
    # Format and structure metadata
    formats = patterns.get('formats', [])
    if formats:
        metadata['formats'] = ','.join(formats)
        metadata['primary_format'] = formats[0] if formats else ''
    
    lengths = patterns.get('lengths', [])
    positions = patterns.get('positions', [])
    metadata['field_lengths'] = ','.join(lengths) if lengths else ''
    metadata['field_positions'] = ','.join(positions) if positions else ''
    
    # Content quality indicators
    definition_elements = ['Format:', 'Technical Name:', 'Length:', 'Position', 'Definition:']
    completeness_score = sum(1 for element in definition_elements if element in doc.page_content)
    metadata['definition_completeness'] = completeness_score
    metadata['is_complete_definition'] = completeness_score >= 4
    
    # Table and structured data metadata
    metadata['has_embedded_tables'] = len(tables) > 0
    metadata['table_count'] = len(tables)
    if tables:
        table_types = [table['type'] for table in tables]
        metadata['table_types'] = ','.join(set(table_types))
    
    # Value mapping metadata
    value_mappings = patterns.get('value_mappings', [])
    metadata['has_value_mappings'] = len(value_mappings) > 0
    metadata['value_mapping_count'] = len(value_mappings)
    
    # Cross-reference metadata
    field_refs = patterns.get('field_references', [])
    metadata['field_references'] = ','.join(field_refs) if field_refs else ''
    metadata['has_field_references'] = len(field_refs) > 0
    metadata['has_appendix_references'] = patterns.get('has_appendix_refs', False)
    
    # Complexity scoring
    complexity_score = 0
    complexity_score += len(numbered_defs) * 10
    complexity_score += len(technical_names) * 5
    complexity_score += len(tables) * 8
    complexity_score += len(value_mappings) * 2
    complexity_score += completeness_score * 3
    metadata['complexity_score'] = min(100, complexity_score)
    
    # Quality indicators
    metadata['is_appendix'] = patterns.get('content_type') == 'appendix'
    metadata['is_lookup_table'] = patterns.get('content_type') == 'value_mapping' or len(value_mappings) > 5
    
    # Search optimization metadata
    if numbered_defs:
        searchable_terms = []
        for num, title in numbered_defs:
            searchable_terms.extend([f"{num}. {title}", title.upper(), title.lower()])
        metadata['searchable_terms'] = ','.join(searchable_terms[:10])  # Limit for ChromaDB
    
    # Ensure all values are ChromaDB compatible
    for key, value in metadata.items():
        if isinstance(value, (list, tuple)):
            metadata[key] = ','.join(str(v) for v in value)
        elif not isinstance(value, (str, int, float, bool, type(None))):
            metadata[key] = str(value)
        elif value is None:
            metadata[key] = ''
    
    return metadata

def smart_chunk_numbered_definitions(text: str, text_splitter: RecursiveCharacterTextSplitter) -> List[str]:
    """Intelligently chunk text while preserving numbered definitions"""
    # First, detect numbered definition boundaries
    boundaries = detect_numbered_definition_boundaries(text)
    
    if not boundaries:
        # No numbered definitions found, use standard chunking
        return [chunk.page_content for chunk in text_splitter.create_documents([text])]
    
    chunks = []
    current_pos = 0
    
    for start_pos, end_pos, definition_title in boundaries:
        # Add any text before the first definition
        if current_pos < start_pos:
            pre_text = text[current_pos:start_pos].strip()
            if pre_text and len(pre_text) > MIN_DEFINITION_SIZE:
                chunks.extend([chunk.page_content for chunk in text_splitter.create_documents([pre_text])])
        
        # Extract the complete definition
        definition_text = text[start_pos:end_pos].strip()
        
        if len(definition_text) <= CHUNK_SIZE:
            # Keep complete definition as one chunk
            chunks.append(definition_text)
        else:
            # Definition is too long, split carefully
            # Try to keep the header with the first part
            lines = definition_text.split('\n')
            current_chunk = []
            current_length = 0
            
            for line in lines:
                if current_length + len(line) > CHUNK_SIZE and current_chunk:
                    chunks.append('\n'.join(current_chunk))
                    current_chunk = []
                    current_length = 0
                
                current_chunk.append(line)
                current_length += len(line) + 1
            
            if current_chunk:
                chunks.append('\n'.join(current_chunk))
        
        current_pos = end_pos
    
    # Add any remaining text
    if current_pos < len(text):
        remaining_text = text[current_pos:].strip()
        if remaining_text and len(remaining_text) > MIN_DEFINITION_SIZE:
            chunks.extend([chunk.page_content for chunk in text_splitter.create_documents([remaining_text])])
    
    return chunks

def load_document_with_tables(file_path: str) -> List[Document]:
    """Load document and extract both main content and embedded tables"""
    extension = os.path.splitext(file_path)[1].lower()
    documents = []
    
    logger.info(f"Loading document: {file_path} ({extension})")
    
    # Choose appropriate loader
    try:
        if extension == ".docx":
            loader = UnstructuredWordDocumentLoader(file_path, mode="elements")
        elif extension == ".doc":
            loader = UnstructuredLoader(file_path, mode="elements", strategy="auto")
        elif extension in [".xlsx", ".xls"]:
            # Handle Excel files specially for embedded tables
            documents.extend(load_excel_with_sheets(file_path))
            return documents
        elif extension == ".pdf":
            loader = PyPDFLoader(file_path)
        elif extension == ".txt":
            loader = TextLoader(file_path, encoding="utf-8")
        else:
            logger.warning(f"Unsupported file type: {extension}")
            return documents
        
        # Load main content
        raw_docs = loader.load()
        
        # Process each document element
        for doc in raw_docs:
            # Preprocess content
            doc.page_content = preprocess_text(doc.page_content)
            
            if len(doc.page_content.strip()) < MIN_DEFINITION_SIZE:
                continue
            
            # Analyze patterns and extract tables
            patterns = analyze_content_patterns(doc.page_content)
            tables = extract_embedded_tables(doc.page_content)
            
            # Create enhanced metadata
            enhanced_metadata = create_enhanced_metadata(doc, patterns, tables, file_path)
            doc.metadata = enhanced_metadata
            
            documents.append(doc)
            
            # Create separate documents for embedded tables
            for table in tables:
                table_doc = Document(
                    page_content=table['formatted_content'],
                    metadata={
                        **enhanced_metadata,
                        'element_type': f"embedded_table_{table['type']}",
                        'is_embedded_table': True,
                        'table_type': table['type'],
                        'parent_content_type': patterns.get('content_type', 'unknown')
                    }
                )
                documents.append(table_doc)
    
    except Exception as e:
        logger.error(f"Error loading {file_path}: {e}")
        if extension == ".doc":
            logger.info("Consider converting .doc to .docx for better processing")
    
    logger.info(f"Processed {len(documents)} elements from {file_path}")
    return documents

def load_excel_with_sheets(file_path: str) -> List[Document]:
    """Special handling for Excel files to extract all sheets and tables"""
    documents = []
    
    try:
        # Use pandas to read all sheets
        excel_file = pd.ExcelFile(file_path)
        
        for sheet_name in excel_file.sheet_names:
            try:
                df = pd.read_excel(file_path, sheet_name=sheet_name)
                
                # Convert DataFrame to text representation
                content_lines = [f"Sheet: {sheet_name}"]
                content_lines.append("-" * (len(sheet_name) + 7))
                
                # Add headers
                if not df.empty:
                    headers = " | ".join(str(col) for col in df.columns)
                    content_lines.append(headers)
                    content_lines.append("-" * len(headers))
                    
                    # Add rows (limit to reasonable number)
                    for idx, row in df.head(50).iterrows():
                        row_text = " | ".join(str(val) for val in row.values)
                        content_lines.append(row_text)
                
                content = "\n".join(content_lines)
                
                # Create document with metadata
                doc = Document(
                    page_content=content,
                    metadata={
                        'source_filename': os.path.basename(file_path),
                        'sheet_name': sheet_name,
                        'element_type': 'excel_sheet',
                        'is_embedded_table': True,
                        'table_type': 'excel_data',
                        'row_count': len(df),
                        'column_count': len(df.columns),
                        'is_complete_definition': False,
                        'is_numbered_definition': False,
                        'content_type': 'value_mapping' if len(df) > 1 else 'descriptive_text'
                    }
                )
                
                documents.append(doc)
                
            except Exception as e:
                logger.warning(f"Could not process sheet {sheet_name}: {e}")
                
    except Exception as e:
        logger.error(f"Error processing Excel file {file_path}: {e}")
        # Fallback to unstructured loader
        try:
            loader = UnstructuredExcelLoader(file_path, mode="elements")
            fallback_docs = loader.load()
            for doc in fallback_docs:
                doc.page_content = preprocess_text(doc.page_content)
                doc.metadata['source_filename'] = os.path.basename(file_path)
                doc.metadata['element_type'] = 'excel_fallback'
                documents.append(doc)
        except Exception as fallback_error:
            logger.error(f"Fallback Excel loading also failed: {fallback_error}")
    
    return documents

def load_all_documents(source_dir: str) -> List[Document]:
    """Load all documents from source directory with enhanced processing"""
    all_documents = []
    
    if not os.path.exists(source_dir):
        logger.error(f"Source directory '{source_dir}' not found")
        return all_documents
    
    supported_extensions = {'.docx', '.doc', '.xlsx', '.xls', '.pdf', '.txt'}
    
    for filename in os.listdir(source_dir):
        if filename.startswith('.'):
            continue
        
        file_path = os.path.join(source_dir, filename)
        extension = os.path.splitext(filename)[1].lower()
        
        if extension in supported_extensions and os.path.isfile(file_path):
            docs = load_document_with_tables(file_path)
            all_documents.extend(docs)
            
            # Log what we found
            numbered_defs = sum(1 for doc in docs if doc.metadata.get('is_numbered_definition'))
            embedded_tables = sum(1 for doc in docs if doc.metadata.get('is_embedded_table'))
            logger.info(f"  Found {numbered_defs} numbered definitions, {embedded_tables} embedded tables")
    
    logger.info(f"Total documents loaded: {len(all_documents)}")
    return all_documents

def create_optimized_chunks(documents: List[Document]) -> List[Document]:
    """Create optimized chunks preserving numbered definitions and tables"""
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=CHUNK_SIZE,
        chunk_overlap=CHUNK_OVERLAP,
        length_function=len,
        separators=[
            "\n\n\n",  # Major section breaks
            "\n\n",    # Paragraph breaks
            "\n",      # Line breaks
            ". ",      # Sentence endings
            ": ",      # Definition separators
            "; ",      # Clause separators
            " ",       # Word boundaries
            ""         # Character level
        ]
    )
    
    final_chunks = []
    
    for doc in documents:
        # Preserve embedded tables and complete definitions as single chunks
        if (doc.metadata.get('is_embedded_table') or 
            (doc.metadata.get('is_numbered_definition') and len(doc.page_content) <= CHUNK_SIZE)):
            doc.metadata['chunk_strategy'] = 'preserved_complete'
            final_chunks.append(doc)
            continue
        
        # Use smart chunking for numbered definitions
        if doc.metadata.get('content_type') == 'numbered_definition':
            smart_chunks = smart_chunk_numbered_definitions(doc.page_content, text_splitter)
            
            for i, chunk_content in enumerate(smart_chunks):
                chunk_doc = Document(
                    page_content=chunk_content,
                    metadata={
                        **doc.metadata,
                        'chunk_index': i,
                        'total_chunks': len(smart_chunks),
                        'chunk_strategy': 'smart_numbered_definition'
                    }
                )
                final_chunks.append(chunk_doc)
        else:
            # Standard chunking for other content
            chunks = text_splitter.split_documents([doc])
            for i, chunk in enumerate(chunks):
                chunk.metadata.update({
                    'chunk_index': i,
                    'total_chunks': len(chunks),
                    'chunk_strategy': 'standard_recursive'
                })
            final_chunks.extend(chunks)
    
    return final_chunks

def analyze_final_collection(documents: List[Document]) -> Dict[str, Any]:
    """Analyze the final document collection for quality assurance"""
    analysis = {
        'total_documents': len(documents),
        'numbered_definitions': 0,
        'embedded_tables': 0,
        'complete_definitions': 0,
        'field_specifications': 0,
        'content_types': {},
        'chunk_strategies': {},
        'definition_numbers': [],
        'quality_metrics': {}
    }
    
    total_content_length = 0
    complexity_scores = []
    
    for doc in documents:
        metadata = doc.metadata
        
        # Count different types
        if metadata.get('is_numbered_definition'):
            analysis['numbered_definitions'] += 1
            if metadata.get('definition_number'):
                analysis['definition_numbers'].append(metadata['definition_number'])
        
        if metadata.get('is_embedded_table'):
            analysis['embedded_tables'] += 1
        
        if metadata.get('is_complete_definition'):
            analysis['complete_definitions'] += 1
        
        if metadata.get('is_field_spec'):
            analysis['field_specifications'] += 1
        
        # Content type distribution
        content_type = metadata.get('content_type', 'unknown')
        analysis['content_types'][content_type] = analysis['content_types'].get(content_type, 0) + 1
        
        # Chunk strategy distribution
        chunk_strategy = metadata.get('chunk_strategy', 'unknown')
        analysis['chunk_strategies'][chunk_strategy] = analysis['chunk_strategies'].get(chunk_strategy, 0) + 1
        
        # Quality metrics
        total_content_length += len(doc.page_content)
        
        complexity = metadata.get('complexity_score', 0)
        if isinstance(complexity, (int, float)):
            complexity_scores.append(complexity)
    
    # Calculate quality metrics
    analysis['quality_metrics'] = {
        'average_content_length': total_content_length / len(documents) if documents else 0,
        'average_complexity': sum(complexity_scores) / len(complexity_scores) if complexity_scores else 0,
        'definition_coverage': len(set(analysis['definition_numbers'])),
        'complete_definition_ratio': analysis['complete_definitions'] / analysis['numbered_definitions'] 
                                   if analysis['numbered_definitions'] else 0
    }
    
    return analysis

def main():
    """Main function to create enhanced ChromaDB with numbered definition optimization"""
    logger.info("Starting enhanced ChromaDB creation...")
    logger.info("Optimized for numbered definitions and embedded tables")
    
    # Clean existing database
    if os.path.exists(CHROMA_DB_DIR):
        logger.info(f"Removing existing ChromaDB at {CHROMA_DB_DIR}")
        shutil.rmtree(CHROMA_DB_DIR)
    
    os.makedirs(CHROMA_DB_DIR, exist_ok=True)
    
    # Load and process documents
    logger.info("Loading documents...")
    documents = load_all_documents(DOCUMENTS_DIR)
    
    if not documents:
        logger.error("No documents loaded. Check source directory and file formats.")
        return
    
    # Create optimized chunks
    logger.info("Creating optimized chunks...")
    chunked_docs = create_optimized_chunks(documents)
    
    # Analyze the collection
    analysis = analyze_final_collection(chunked_docs)
    
    # Log analysis results
    logger.info("\n=== COLLECTION ANALYSIS ===")
    logger.info(f"Total chunks: {analysis['total_documents']}")
    logger.info(f"Numbered definitions: {analysis['numbered_definitions']}")
    logger.info(f"Embedded tables: {analysis['embedded_tables']}")
    logger.info(f"Complete definitions: {analysis['complete_definitions']}")
    logger.info(f"Definition coverage: {analysis['quality_metrics']['definition_coverage']} unique numbers")
    
    logger.info("\nContent Types:")
    for content_type, count in analysis['content_types'].items():
        logger.info(f"  {content_type}: {count}")
    
    logger.info("\nChunk Strategies:")
    for strategy, count in analysis['chunk_strategies'].items():
        logger.info(f"  {strategy}: {count}")
    
    # Prepare data for ChromaDB
    ids = [f"doc_{i}" for i in range(len(chunked_docs))]
    contents = [doc.page_content for doc in chunked_docs]
    metadatas = [doc.metadata for doc in chunked_docs]
    
    # Generate embeddings
    logger.info("Generating embeddings...")
    try:
        embeddings_list = embeddings.embed_documents(contents)
        logger.info(f"Generated {len(embeddings_list)} embeddings")
    except Exception as e:
        logger.error(f"Error generating embeddings: {e}")
        return
    
    # Initialize ChromaDB and add documents
    logger.info("Storing in ChromaDB...")
    try:
        client = chromadb.PersistentClient(path=CHROMA_DB_DIR)
        collection = client.get_or_create_collection(name=COLLECTION_NAME)
        
        # Add in batches for large collections
        batch_size = 500
        for i in range(0, len(ids), batch_size):
            end_idx = min(i + batch_size, len(ids))
            batch_ids = ids[i:end_idx]
            batch_embeddings = embeddings_list[i:end_idx]
            batch_contents = contents[i:end_idx]
            batch_metadatas = metadatas[i:end_idx]
            
            collection.add(
                ids=batch_ids,
                embeddings=batch_embeddings,
                documents=batch_contents,
                metadatas=batch_metadatas
            )
            
            logger.info(f"Added batch {i//batch_size + 1}: {len(batch_ids)} documents")
        
        # Verify final count
        final_count = collection.count()
        logger.info(f"Final collection size: {final_count} documents")
        
        # Test query
        logger.info("Testing query functionality...")
        test_embedding = embeddings.embed_query("HCFA Admit Type Code")
        test_results = collection.query(
            query_embeddings=[test_embedding],
            n_results=3,
            include=["documents", "metadatas"]
        )
        
        if test_results and test_results.get('documents'):
            logger.info(f"Test query returned {len(test_results['documents'][0])} results")
            first_result = test_results['documents'][0][0]
            logger.info(f"First result preview: {first_result[:100]}...")
            
            # Check for numbered definition
            first_metadata = test_results.get('metadatas', [[]])[0][0] if test_results.get('metadatas') else {}
            if first_metadata.get('is_numbered_definition'):
                logger.info(f"Found numbered definition: {first_metadata.get('definition_number', 'N/A')}")
        
        logger.info("\n=== SUCCESS ===")
        logger.info("Enhanced ChromaDB created successfully!")
        logger.info("Optimized for numbered definitions and embedded tables")
        logger.info(f"Total indexed: {final_count} documents")
        logger.info(f"Numbered definitions: {analysis['numbered_definitions']}")
        logger.info(f"Embedded tables: {analysis['embedded_tables']}")
        
    except Exception as e:
        logger.error(f"Error creating ChromaDB: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    if not os.path.exists(DOCUMENTS_DIR):
        logger.error(f"Documents directory '{DOCUMENTS_DIR}' not found")
        logger.info("Please create the directory and add your documents")
        os.makedirs(DOCUMENTS_DIR, exist_ok=True)
    elif not os.listdir(DOCUMENTS_DIR):
        logger.warning(f"Documents directory '{DOCUMENTS_DIR}' is empty")
        logger.info("Please add document files to this directory")
    else:
        main()
