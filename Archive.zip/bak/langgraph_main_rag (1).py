# Enhanced RAG system with LangGraph workflow
# Optimized for all data types in the universal medical/dental data dictionary

import os
from dotenv import load_dotenv 
from flask import Flask, request, jsonify, render_template 
from langchain_google_vertexai import VertexAIEmbeddings, ChatVertexAI
import chromadb
import sys 
import re 
from typing import TypedDict, List, Dict, Optional, Literal
from langgraph import StateGraph, START, END
from langgraph.graph import Graph
import logging

load_dotenv() 

# --- Configuration ---
CHROMA_DB_DIR = "./chroma_db_data"
COLLECTION_NAME = "rag_collection"
EMBEDDING_MODEL_NAME = "text-embedding-005"
CHAT_MODEL_NAME = "gemini-2.5-pro-preview-05-06"
GCP_PROJECT_ID = os.getenv("GOOGLE_CLOUD_PROJECT")

LLM_TEMPERATURE = 0.05
NUM_RETRIEVED_DOCS = 20
RETRIEVAL_DISTANCE_THRESHOLD = 0.85

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__, template_folder='templates')

# Global variables
embeddings_service = None
chat_model = None
chroma_client = None
collection = None
rag_workflow = None

# Define the state for the LangGraph workflow
class RAGState(TypedDict):
    query: str
    user_query_term: str
    query_type: Literal["numbered_definition", "field_lookup", "concept_search", "general"]
    retrieval_strategies: List[str]
    retrieved_docs: List[Dict]
    processed_docs: List[Dict]
    context_string: str
    final_answer: str
    confidence_score: float
    retry_count: int
    error_message: Optional[str]

def init_clients_rag(): 
    global embeddings_service, chat_model, chroma_client, collection
    if not GCP_PROJECT_ID:
        raise ValueError("GOOGLE_CLOUD_PROJECT environment variable is essential and not set.")
    
    if not embeddings_service:
        embeddings_service = VertexAIEmbeddings(model_name=EMBEDDING_MODEL_NAME, project=GCP_PROJECT_ID)
    
    if not chat_model:
        chat_model = ChatVertexAI(model_name=CHAT_MODEL_NAME, project=GCP_PROJECT_ID, temperature=LLM_TEMPERATURE) 
        logger.info(f"Initialized ChatVertexAI with model: {CHAT_MODEL_NAME}")
    
    if not chroma_client:
        if not os.path.exists(CHROMA_DB_DIR):
            raise FileNotFoundError(f"ChromaDB directory '{CHROMA_DB_DIR}' missing. Run create_chroma_db.py first.")
        chroma_client = chromadb.PersistentClient(path=CHROMA_DB_DIR)
    
    if not collection:
        try:
            collection = chroma_client.get_collection(name=COLLECTION_NAME)
            logger.info(f"Loaded Chroma collection '{COLLECTION_NAME}' ({collection.count()} items).")
        except Exception as e:
            logger.error(f"Error: Collection '{COLLECTION_NAME}' not found: {e}")
            raise

# Query Analysis Node
def analyze_query(state: RAGState) -> RAGState:
    """Analyze the query and determine the best retrieval strategy"""
    query = state["query"]
    
    # Extract the core term from various query patterns
    patterns = {
        "numbered_definition": r"(\d+)\.\s*([^:?\n]+)",
        "field_lookup": r"(?:what is|define|explain)\s+(.+?)(?:\?|$)",
        "direct_term": r"^([A-Z_]+)$",  # Technical names like AHF_BFD_AMT
        "concept_phrase": r"^([^?]+?)(?:\?|$)"
    }
    
    query_type = "general"
    user_query_term = query.strip()
    
    # Check for numbered definition pattern
    numbered_match = re.search(patterns["numbered_definition"], query, re.IGNORECASE)
    if numbered_match:
        query_type = "numbered_definition"
        user_query_term = numbered_match.group(2).strip()
        logger.info(f"Detected numbered definition: {numbered_match.group(1)}. {user_query_term}")
    
    # Check for field lookup patterns
    elif re.search(patterns["field_lookup"], query, re.IGNORECASE):
        field_match = re.search(patterns["field_lookup"], query, re.IGNORECASE)
        if field_match:
            query_type = "field_lookup"
            user_query_term = field_match.group(1).strip()
            # Remove number prefix if present
            user_query_term = re.sub(r'^\d+\.\s*', '', user_query_term)
            logger.info(f"Detected field lookup: {user_query_term}")
    
    # Check for direct technical terms
    elif re.search(patterns["direct_term"], query.strip()):
        query_type = "field_lookup"
        user_query_term = query.strip()
        logger.info(f"Detected direct technical term: {user_query_term}")
    
    # Default to concept search
    else:
        query_type = "concept_search"
        concept_match = re.search(patterns["concept_phrase"], query, re.IGNORECASE)
        if concept_match:
            user_query_term = concept_match.group(1).strip()
        logger.info(f"Detected concept search: {user_query_term}")
    
    # Clean up the term
    user_query_term = user_query_term.strip('\'"').strip()
    
    return {
        **state,
        "user_query_term": user_query_term,
        "query_type": query_type,
        "retry_count": 0,
        "confidence_score": 0.0
    }

# Numbered Definition Retrieval Node
def numbered_definition_retrieval(state: RAGState) -> RAGState:
    """Specialized retrieval for numbered definitions"""
    query = state["query"]
    user_query_term = state["user_query_term"]
    
    # Extract number from query
    number_match = re.search(r'(\d+)\.?\s*', query)
    if not number_match:
        return state
    
    number = number_match.group(1)
    
    # Multiple search strategies for numbered definitions
    search_queries = [
        f"{number}. {user_query_term}:",  # Exact format
        f"{number}. {user_query_term.upper()}:",  # Uppercase version
        f"{number}. {user_query_term}",  # Without colon
        f"{user_query_term} {number}",  # Term with number
        user_query_term,  # Just the term
    ]
    
    all_results = []
    seen_docs = set()
    
    for search_query in search_queries:
        try:
            query_embedding = embeddings_service.embed_query(search_query)
            results = collection.query(
                query_embeddings=[query_embedding],
                n_results=5,
                include=["documents", "metadatas", "distances"]
            )
            
            if results and results.get('documents'):
                for i, doc in enumerate(results.get('documents', [[]])[0]):
                    if doc not in seen_docs:
                        seen_docs.add(doc)
                        metadata = results.get('metadatas', [[]])[0][i] if i < len(results.get('metadatas', [[]])[0]) else {}
                        distance = results.get('distances', [[]])[0][i] if i < len(results.get('distances', [[]])[0]) else 1.0
                        
                        # Check for exact match
                        is_exact_match = bool(re.search(rf"{number}\.\s*{re.escape(user_query_term)}", doc, re.IGNORECASE))
                        
                        all_results.append({
                            'content': doc,
                            'metadata': metadata,
                            'distance': distance,
                            'is_exact_match': is_exact_match,
                            'retrieval_strategy': 'numbered_definition'
                        })
                        
        except Exception as e:
            logger.error(f"Error in numbered definition search: {e}")
    
    # Sort by exact match first, then by distance
    all_results.sort(key=lambda x: (not x.get('is_exact_match', False), x['distance']))
    
    return {
        **state,
        "retrieved_docs": all_results[:10],
        "retrieval_strategies": state.get("retrieval_strategies", []) + ["numbered_definition"]
    }

# Field Lookup Retrieval Node
def field_lookup_retrieval(state: RAGState) -> RAGState:
    """Specialized retrieval for field names and technical terms"""
    user_query_term = state["user_query_term"]
    
    # Multiple search strategies for field lookup
    search_queries = [
        user_query_term,  # Exact term
        user_query_term.upper(),  # Uppercase version
        user_query_term.lower(),  # Lowercase version
        f"Technical Name: {user_query_term}",  # With technical name prefix
        f"Field {user_query_term}",  # With field prefix
    ]
    
    all_results = []
    seen_docs = set()
    
    for search_query in search_queries:
        try:
            query_embedding = embeddings_service.embed_query(search_query)
            results = collection.query(
                query_embeddings=[query_embedding],
                n_results=5,
                include=["documents", "metadatas", "distances"]
            )
            
            if results and results.get('documents'):
                for i, doc in enumerate(results.get('documents', [[]])[0]):
                    if doc not in seen_docs:
                        seen_docs.add(doc)
                        metadata = results.get('metadatas', [[]])[0][i] if i < len(results.get('metadatas', [[]])[0]) else {}
                        distance = results.get('distances', [[]])[0][i] if i < len(results.get('distances', [[]])[0]) else 1.0
                        
                        # Check for field-specific patterns
                        is_field_match = bool(re.search(rf"Technical Name:\s*{re.escape(user_query_term)}", doc, re.IGNORECASE))
                        
                        all_results.append({
                            'content': doc,
                            'metadata': metadata,
                            'distance': distance,
                            'is_field_match': is_field_match,
                            'retrieval_strategy': 'field_lookup'
                        })
                        
        except Exception as e:
            logger.error(f"Error in field lookup search: {e}")
    
    # Sort by field match first, then by distance
    all_results.sort(key=lambda x: (not x.get('is_field_match', False), x['distance']))
    
    return {
        **state,
        "retrieved_docs": all_results[:10],
        "retrieval_strategies": state.get("retrieval_strategies", []) + ["field_lookup"]
    }

# Semantic Retrieval Node
def semantic_retrieval(state: RAGState) -> RAGState:
    """General semantic retrieval for concept-based queries"""
    user_query_term = state["user_query_term"]
    query = state["query"]
    
    # Enhanced query rewriting for better semantic matching
    rewrite_prompt = f"""
    Optimize the following query for semantic search in a medical data dictionary.
    The dictionary contains field definitions, technical specifications, and explanations.
    
    Original query: "{query}"
    Core term: "{user_query_term}"
    
    Create an optimized search query that captures the essential meaning and likely variations.
    Return only the optimized query without explanation.
    """
    
    try:
        optimized_query = chat_model.invoke(rewrite_prompt).content.strip()
        if not optimized_query:
            optimized_query = user_query_term
    except Exception as e:
        logger.error(f"Error in query rewriting: {e}")
        optimized_query = user_query_term
    
    # Perform semantic search
    try:
        query_embedding = embeddings_service.embed_query(optimized_query)
        results = collection.query(
            query_embeddings=[query_embedding],
            n_results=NUM_RETRIEVED_DOCS,
            include=["documents", "metadatas", "distances"]
        )
        
        retrieved_docs = []
        if results and results.get('documents'):
            for i, doc in enumerate(results.get('documents', [[]])[0]):
                metadata = results.get('metadatas', [[]])[0][i] if i < len(results.get('metadatas', [[]])[0]) else {}
                distance = results.get('distances', [[]])[0][i] if i < len(results.get('distances', [[]])[0]) else 1.0
                
                retrieved_docs.append({
                    'content': doc,
                    'metadata': metadata,
                    'distance': distance,
                    'retrieval_strategy': 'semantic'
                })
        
        return {
            **state,
            "retrieved_docs": retrieved_docs,
            "retrieval_strategies": state.get("retrieval_strategies", []) + ["semantic"]
        }
    
    except Exception as e:
        logger.error(f"Error in semantic retrieval: {e}")
        return {
            **state,
            "error_message": f"Semantic retrieval failed: {e}"
        }

# Document Processing and Ranking Node
def process_and_rank_documents(state: RAGState) -> RAGState:
    """Process and rank retrieved documents based on relevance"""
    retrieved_docs = state["retrieved_docs"]
    user_query_term = state["user_query_term"]
    query = state["query"]
    query_type = state["query_type"]
    
    if not retrieved_docs:
        return state
    
    # Enhanced scoring based on document type and content
    processed_docs = []
    
    for doc in retrieved_docs:
        content = doc['content']
        metadata = doc['metadata']
        distance = doc['distance']
        
        # Calculate relevance score
        relevance_score = 0.0
        
        # 1. Query type specific scoring
        if query_type == "numbered_definition":
            # Look for exact numbered definition pattern
            number_match = re.search(r'(\d+)\.?\s*', query)
            if number_match:
                number = number_match.group(1)
                exact_pattern = rf"^{number}\.\s*{re.escape(user_query_term)}:\s*"
                if re.search(exact_pattern, content, re.IGNORECASE):
                    relevance_score += 100.0
        
        elif query_type == "field_lookup":
            # Look for technical name or field definition patterns
            if re.search(rf"Technical Name:\s*{re.escape(user_query_term)}", content, re.IGNORECASE):
                relevance_score += 80.0
            if re.search(rf"^{re.escape(user_query_term)}:", content, re.IGNORECASE):
                relevance_score += 70.0
        
        # 2. General content matching
        if re.search(rf"\b{re.escape(user_query_term)}\b", content, re.IGNORECASE):
            relevance_score += 30.0
        
        # 3. Metadata-based scoring (handle string metadata)
        if metadata.get("is_complete_definition") == True or metadata.get("is_complete_definition") == "True":
            relevance_score += 25.0
        if metadata.get("is_numbered_definition") == True or metadata.get("is_numbered_definition") == "True":
            relevance_score += 20.0
        
        # Handle definition_completeness as string or int
        def_completeness = metadata.get("definition_completeness", 0)
        if isinstance(def_completeness, str) and def_completeness.isdigit():
            def_completeness = int(def_completeness)
        elif not isinstance(def_completeness, int):
            def_completeness = 0
            
        if def_completeness >= 3:
            relevance_score += 15.0
        
        # 4. Distance-based scoring (inverse)
        distance_score = max(0, 20.0 * (1.0 - distance))
        relevance_score += distance_score
        
        # 5. Content quality indicators
        definition_indicators = ['Format:', 'Technical Name:', 'Length:', 'Positions:', 'Definition:']
        indicator_count = sum(1 for indicator in definition_indicators if indicator in content)
        relevance_score += indicator_count * 5.0
        
        # 6. Penalty for very short or incomplete content
        if len(content.strip()) < 50:
            relevance_score -= 10.0
        
        processed_docs.append({
            **doc,
            'relevance_score': relevance_score,
            'quality_indicators': {
                'has_definition_structure': indicator_count >= 3,
                'is_complete': metadata.get("is_complete_definition", False),
                'content_length': len(content),
                'confidence': min(1.0, relevance_score / 100.0)
            }
        })
    
    # Sort by relevance score
    processed_docs.sort(key=lambda x: x['relevance_score'], reverse=True)
    
    # Calculate overall confidence
    top_score = processed_docs[0]['relevance_score'] if processed_docs else 0
    confidence_score = min(1.0, top_score / 100.0)
    
    return {
        **state,
        "processed_docs": processed_docs,
        "confidence_score": confidence_score
    }

# Context Building Node
def build_context(state: RAGState) -> RAGState:
    """Build context string from processed documents"""
    processed_docs = state["processed_docs"]
    query_type = state["query_type"]
    
    if not processed_docs:
        return {
            **state,
            "context_string": "No relevant information found.",
            "confidence_score": 0.0
        }
    
    # Filter documents by distance threshold and relevance
    filtered_docs = [
        doc for doc in processed_docs 
        if doc['distance'] <= RETRIEVAL_DISTANCE_THRESHOLD and doc['relevance_score'] > 10.0
    ]
    
    if not filtered_docs:
        return {
            **state,
            "context_string": "No relevant information found matching quality criteria.",
            "confidence_score": 0.0
        }
    
    # Build context with source attribution
    context_parts = []
    for i, doc in enumerate(filtered_docs[:5]):  # Limit to top 5 documents
        metadata = doc['metadata']
        content = doc['content']
        source = metadata.get('source_filename', 'Unknown source')
        page = metadata.get('page_number', 'N/A')
        element_type = metadata.get('element_type', 'text')
        
        context_parts.append(
            f"[Source: {source}, Page: {page}, Type: {element_type}, Score: {doc['relevance_score']:.1f}]\n{content}"
        )
    
    context_string = "\n\n---\n\n".join(context_parts)
    
    return {
        **state,
        "context_string": context_string
    }

# Answer Generation Node
def generate_answer(state: RAGState) -> RAGState:
    """Generate the final answer based on context and query type"""
    context_string = state["context_string"]
    query = state["query"]
    user_query_term = state["user_query_term"]
    query_type = state["query_type"]
    confidence_score = state["confidence_score"]
    
    if not context_string or context_string == "No relevant information found.":
        return {
            **state,
            "final_answer": "I could not find relevant information for your query in the document.",
            "confidence_score": 0.0
        }
    
    # Create query-type specific prompts
    if query_type == "numbered_definition":
        prompt_template = """You are an AI assistant that extracts numbered definitions from a medical data dictionary.

The user asked about: "{original_question}"
The specific numbered definition term is: "{user_term}"

INSTRUCTIONS:
1. Find and reproduce the complete numbered definition EXACTLY as it appears in the document
2. Include all structured information (Format, Technical Name, Length, Positions, Definition, etc.)
3. Preserve all formatting including bullet points, colons, and spacing
4. If you find the complete definition, present it as the primary answer
5. If only partial information is available, clearly indicate what's missing

Context from the document:
---
{context}
---

Response (reproduce the exact numbered definition with all formatting):"""
    
    elif query_type == "field_lookup":
        prompt_template = """You are an AI assistant that explains fields and technical terms from a medical data dictionary.

The user asked about: "{original_question}"
The specific field/term is: "{user_term}"

INSTRUCTIONS:
1. Find the complete definition for the specified field or technical term
2. Include all available information (Format, Technical Name, Length, Definition, etc.)
3. Explain what the field represents and how it's used
4. Preserve exact formatting from the source document
5. If multiple related fields are found, present the most relevant one

Context from the document:
---
{context}
---

Response (provide complete field information and explanation):"""
    
    else:  # concept_search or general
        prompt_template = """You are an AI assistant that explains concepts from a medical data dictionary.

The user asked about: "{original_question}"
The concept they're interested in is: "{user_term}"

INSTRUCTIONS:
1. Provide a comprehensive explanation based on the available context
2. Include any relevant definitions, examples, or related information
3. Organize the information clearly and logically
4. Cite specific sections when referencing exact definitions
5. If the context contains multiple related concepts, explain how they connect

Context from the document:
---
{context}
---

Response (provide comprehensive explanation):"""
    
    # Generate the answer
    final_prompt = prompt_template.format(
        original_question=query,
        user_term=user_query_term,
        context=context_string
    )
    
    try:
        response = chat_model.invoke(final_prompt)
        final_answer = response.content.strip()
        
        # Adjust confidence based on answer quality
        if "could not find" in final_answer.lower() or "no information" in final_answer.lower():
            confidence_score *= 0.5
        
        return {
            **state,
            "final_answer": final_answer,
            "confidence_score": confidence_score
        }
    
    except Exception as e:
        logger.error(f"Error generating answer: {e}")
        return {
            **state,
            "final_answer": f"Error generating response: {e}",
            "confidence_score": 0.0
        }

# Validation Node
def validate_answer(state: RAGState) -> RAGState:
    """Validate the quality of the generated answer"""
    final_answer = state["final_answer"]
    query_type = state["query_type"]
    user_query_term = state["user_query_term"]
    confidence_score = state["confidence_score"]
    
    validation_score = confidence_score
    
    # Query type specific validation
    if query_type == "numbered_definition":
        # Check if answer contains numbered definition pattern
        if re.search(r'\d+\.\s*[^:]+:', final_answer):
            validation_score += 0.2
        # Check for definition structure elements
        definition_elements = ['Format:', 'Technical Name:', 'Length:', 'Positions:', 'Definition:']
        element_count = sum(1 for element in definition_elements if element in final_answer)
        validation_score += (element_count / len(definition_elements)) * 0.3
    
    elif query_type == "field_lookup":
        # Check for field-specific information
        if re.search(rf'{re.escape(user_query_term)}.*:', final_answer, re.IGNORECASE):
            validation_score += 0.2
        if 'Technical Name:' in final_answer or 'Format:' in final_answer:
            validation_score += 0.2
    
    # General quality checks
    if len(final_answer) > 100:  # Substantial answer
        validation_score += 0.1
    if final_answer.count(':') >= 2:  # Structured information
        validation_score += 0.1
    
    # Cap the validation score
    validation_score = min(1.0, validation_score)
    
    return {
        **state,
        "confidence_score": validation_score
    }

# Route selection function
def route_retrieval_strategy(state: RAGState) -> str:
    """Determine which retrieval strategy to use based on query analysis"""
    query_type = state["query_type"]
    
    if query_type == "numbered_definition":
        return "numbered_definition"
    elif query_type == "field_lookup":
        return "field_lookup"
    else:
        return "semantic"

# Route validation function
def route_validation(state: RAGState) -> str:
    """Determine if answer needs retry or is acceptable"""
    confidence_score = state["confidence_score"]
    retry_count = state["retry_count"]
    
    # If confidence is too low and we haven't retried much, try different strategy
    if confidence_score < 0.3 and retry_count < 2:
        return "retry"
    else:
        return "end"

# Retry logic node
def retry_with_fallback(state: RAGState) -> RAGState:
    """Retry with a different strategy if initial attempt failed"""
    retry_count = state["retry_count"]
    query_type = state["query_type"]
    
    # Increment retry count
    new_retry_count = retry_count + 1
    
    # Determine fallback strategy
    if query_type == "numbered_definition" and retry_count == 0:
        # Fall back to field lookup
        new_query_type = "field_lookup"
    elif query_type == "field_lookup" and retry_count == 0:
        # Fall back to semantic search
        new_query_type = "concept_search"
    else:
        # Final fallback to semantic search
        new_query_type = "concept_search"
    
    logger.info(f"Retrying with strategy: {new_query_type} (attempt {new_retry_count})")
    
    return {
        **state,
        "query_type": new_query_type,
        "retry_count": new_retry_count,
        "retrieved_docs": [],  # Clear previous results
        "processed_docs": [],
        "context_string": "",
        "confidence_score": 0.0
    }

def create_rag_workflow() -> Graph:
    """Create the complete RAG workflow using LangGraph"""
    
    # Create the workflow graph
    workflow = StateGraph(RAGState)
    
    # Add nodes
    workflow.add_node("analyze_query", analyze_query)
    workflow.add_node("numbered_definition_retrieval", numbered_definition_retrieval)
    workflow.add_node("field_lookup_retrieval", field_lookup_retrieval)
    workflow.add_node("semantic_retrieval", semantic_retrieval)
    workflow.add_node("process_and_rank", process_and_rank_documents)
    workflow.add_node("build_context", build_context)
    workflow.add_node("generate_answer", generate_answer)
    workflow.add_node("validate_answer", validate_answer)
    workflow.add_node("retry_with_fallback", retry_with_fallback)
    
    # Set entry point
    workflow.set_entry_point("analyze_query")
    
    # Add conditional edges for routing
    workflow.add_conditional_edges(
        "analyze_query",
        route_retrieval_strategy,
        {
            "numbered_definition": "numbered_definition_retrieval",
            "field_lookup": "field_lookup_retrieval",
            "semantic": "semantic_retrieval"
        }
    )
    
    # Add sequential edges from retrieval to processing
    workflow.add_edge("numbered_definition_retrieval", "process_and_rank")
    workflow.add_edge("field_lookup_retrieval", "process_and_rank")
    workflow.add_edge("semantic_retrieval", "process_and_rank")
    
    # Continue the workflow
    workflow.add_edge("process_and_rank", "build_context")
    workflow.add_edge("build_context", "generate_answer")
    workflow.add_edge("generate_answer", "validate_answer")
    
    # Add conditional validation routing
    workflow.add_conditional_edges(
        "validate_answer",
        route_validation,
        {
            "retry": "retry_with_fallback",
            "end": END
        }
    )
    
    # Route from retry back to retrieval
    workflow.add_conditional_edges(
        "retry_with_fallback",
        route_retrieval_strategy,
        {
            "numbered_definition": "numbered_definition_retrieval",
            "field_lookup": "field_lookup_retrieval",
            "semantic": "semantic_retrieval"
        }
    )
    
    return workflow.compile()

# Initialize everything
try:
    init_clients_rag()
    rag_workflow = create_rag_workflow()
    logger.info("RAG workflow initialized successfully")
except Exception as e:
    logger.error(f"FATAL: Error during RAG initialization: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

@app.route('/')
def index_route(): 
    return render_template('chat.html')

@app.route('/chat_rag', methods=['POST']) 
def chat_handler_rag():
    """Enhanced chat handler using LangGraph workflow"""
    if not rag_workflow:
        return jsonify({"error": "RAG workflow not initialized."}), 500

    data = request.get_json()
    user_query = data.get('query')
    if not user_query: 
        return jsonify({"error": "Query not provided"}), 400

    try:
        # Initialize state
        initial_state = RAGState(
            query=user_query,
            user_query_term="",
            query_type="general",
            retrieval_strategies=[],
            retrieved_docs=[],
            processed_docs=[],
            context_string="",
            final_answer="",
            confidence_score=0.0,
            retry_count=0,
            error_message=None
        )
        
        # Run the workflow
        logger.info(f"Processing query: {user_query}")
        final_state = rag_workflow.invoke(initial_state)
        
        # Extract results
        final_answer = final_state.get("final_answer", "No answer generated")
        confidence_score = final_state.get("confidence_score", 0.0)
        retrieval_strategies = final_state.get("retrieval_strategies", [])
        
        # Get source metadata from processed docs
        source_metadata = []
        for doc in final_state.get("processed_docs", [])[:5]:
            metadata = doc.get("metadata", {})
            source_metadata.append({
                "source": metadata.get("source_filename", "Unknown"),
                "page": metadata.get("page_number", "N/A"),
                "type": metadata.get("element_type", "text"),
                "score": doc.get("relevance_score", 0.0)
            })
        
        logger.info(f"Query processed. Confidence: {confidence_score:.2f}, Strategies: {retrieval_strategies}")
        
        return jsonify({
            "answer": final_answer,
            "confidence_score": confidence_score,
            "retrieval_strategies": retrieval_strategies,
            "retrieved_sources_metadata": source_metadata,
            "query_type": final_state.get("query_type", "unknown")
        })

    except Exception as e:
        logger.error(f"Error processing chat query: {e}", exc_info=True)
        return jsonify({"error": "An internal error occurred. Please check server logs."}), 500

# Backward compatibility route
@app.route('/chat', methods=['POST'])
def chat_handler_fallback():
    return chat_handler_rag()

if __name__ == '__main__':
    logger.info("Starting Enhanced RAG Flask application with LangGraph...")
    logger.info(f"GOOGLE_CLOUD_PROJECT: {GCP_PROJECT_ID}")
    if not GCP_PROJECT_ID:
        logger.warning("GOOGLE_CLOUD_PROJECT not set. The application may not work properly.")
    
    app.run(debug=True, host='0.0.0.0', port=int(os.environ.get('PORT', 8081)))