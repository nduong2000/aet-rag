# Enhanced RAG system with LangGraph workflow
# Optimized for numbered definitions and embedded table content

import os
from dotenv import load_dotenv 
from flask import Flask, request, jsonify, render_template 
from langchain_google_vertexai import VertexAIEmbeddings, ChatVertexAI
import chromadb
import sys 
import re 
from typing import TypedDict, List, Dict, Optional, Literal, Tuple
try:
    from langgraph.graph import StateGraph, START, END
    from langgraph.graph.graph import CompiledGraph
    LANGGRAPH_AVAILABLE = True
except ImportError:
    try:
        from langgraph import StateGraph, START, END
        from langgraph import Graph as CompiledGraph
        LANGGRAPH_AVAILABLE = True
    except ImportError:
        print("Warning: LangGraph not available. Using fallback implementation.")
        LANGGRAPH_AVAILABLE = False
        # Create dummy classes for fallback
        class StateGraph:
            def __init__(self, state_type): pass
            def add_node(self, name, func): pass
            def add_edge(self, source, target): pass
            def add_conditional_edges(self, source, condition, mapping): pass
            def set_entry_point(self, node): pass
            def compile(self): return FallbackGraph()
        
        class FallbackGraph:
            def invoke(self, state): return fallback_rag_pipeline(state)
        
        START = "START"
        END = "END"
        CompiledGraph = FallbackGraph
import logging

load_dotenv() 

# --- Configuration ---
CHROMA_DB_DIR = "./chroma_db_data"
COLLECTION_NAME = "rag_collection"
EMBEDDING_MODEL_NAME = "text-embedding-005"
CHAT_MODEL_NAME = "gemini-2.5-pro-preview-05-06"  # Default model
AVAILABLE_MODELS = {
    "gemini-2.5-pro-preview-05-06": {"temperature": 0.05},
    "gemini-2.5-flash-preview-04-17": {"temperature": 0.1}
}
GCP_PROJECT_ID = os.getenv("GOOGLE_CLOUD_PROJECT")

LLM_TEMPERATURE = 0.05
NUM_RETRIEVED_DOCS = 25
RETRIEVAL_DISTANCE_THRESHOLD = 0.85

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__, template_folder='templates')

# Global variables
embeddings_service = None
chat_model = None
chroma_client = None
collection = None
rag_workflow = None

# Define the state for the LangGraph workflow
class RAGState(TypedDict):
    query: str
    user_query_term: str
    query_type: Literal["numbered_definition", "field_lookup", "concept_search", "general"]
    extracted_number: Optional[str]
    retrieval_strategies: List[str]
    retrieved_docs: List[Dict]
    processed_docs: List[Dict]
    context_string: str
    final_answer: str
    confidence_score: float
    retry_count: int
    error_message: Optional[str]

def init_clients_rag(): 
    global embeddings_service, chat_model, chroma_client, collection
    if not GCP_PROJECT_ID:
        raise ValueError("GOOGLE_CLOUD_PROJECT environment variable is essential and not set.")
    
    if not embeddings_service:
        embeddings_service = VertexAIEmbeddings(model_name=EMBEDDING_MODEL_NAME, project=GCP_PROJECT_ID)
    
    if not chroma_client:
        if not os.path.exists(CHROMA_DB_DIR):
            raise FileNotFoundError(f"ChromaDB directory '{CHROMA_DB_DIR}' missing. Run create_chroma_db.py first.")
        chroma_client = chromadb.PersistentClient(path=CHROMA_DB_DIR)
    
    if not collection:
        try:
            collection = chroma_client.get_collection(name=COLLECTION_NAME)
            logger.info(f"Loaded Chroma collection '{COLLECTION_NAME}' ({collection.count()} items).")
        except Exception as e:
            logger.error(f"Error: Collection '{COLLECTION_NAME}' not found: {e}")
            raise

def get_chat_model(model_name=None):
    if not model_name or model_name not in AVAILABLE_MODELS:
        model_name = CHAT_MODEL_NAME  # Default model
        
    model_config = AVAILABLE_MODELS[model_name]
    temperature = model_config.get("temperature", LLM_TEMPERATURE)
    
    logger.info(f"Initializing ChatVertexAI with model: {model_name}, temperature: {temperature}")
    return ChatVertexAI(
        model_name=model_name, 
        project=GCP_PROJECT_ID, 
        temperature=temperature
    )

def extract_field_number_from_definition(text: str) -> Optional[str]:
    """Extract field number from a definition that mentions 'Field #X'"""
    # Look for patterns like "Field #141" or "field 141"
    field_ref_patterns = [
        r"field\s*#?\s*(\d+)",
        r"refer.*?field\s*#?\s*(\d+)",
        r"see.*?field\s*#?\s*(\d+)"
    ]
    
    for pattern in field_ref_patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            return match.group(1)
    return None

def find_definition_by_name(user_query_term: str) -> List[str]:
    """Find potential definition numbers by searching for the term name in the knowledge base"""
    # This is a lookup table for common fields - in a real system this could be dynamic
    field_name_to_number = {
        "hcfa admit type code": "141",
        "hcfa admit type": "141", 
        "admit type code": "141",
        "hcfa admit source code": "140",
        "hcfa admit source": "140",
        "admit source code": "140",
        "hcfa place of service": "139",
        "hcfa place of service code": "139",
        "place of service": "77",
        "pricing method code": "131",
        "pricing method": "131",
        "diagnosis code 6": "158",
        "diagnosis code 1": "153",
        "ahf_bfd_amt": "102",
        "aetna health fund before fund deductible": "102",
        "ahf before fund deductible": "102",
        "cob paid amount": "101",
        "coordination of benefits paid amount": "101",
        "paid amount": "100",
        "benefit payable": "99"
    }
    
    # Normalize the search term
    normalized_term = user_query_term.lower().strip()
    
    # Direct lookup
    if normalized_term in field_name_to_number:
        return [field_name_to_number[normalized_term]]
    
    # Partial matching
    potential_numbers = []
    for name, number in field_name_to_number.items():
        if normalized_term in name or name in normalized_term:
            potential_numbers.append(number)
    
    return potential_numbers

# Enhanced Query Analysis Node
def analyze_query(state: RAGState) -> RAGState:
    """Enhanced query analysis with better pattern detection for numbered definitions"""
    query = state["query"]
    
    # Initialize variables
    query_type = "general"
    user_query_term = query.strip()
    extracted_number = None
    
    # Pattern 1: Direct numbered definition (e.g., "141. HCFA Admit Type Code")
    numbered_definition_patterns = [
        r"^(\d+)\.\s*([^:?\n]+)",  # "141. HCFA Admit Type Code"
        r"(\d+)\.\s*([^:?\n]+):",  # "141. HCFA Admit Type Code:"
        r"^(\d+)\s+([^:?\n]+)",    # "141 HCFA Admit Type Code"
    ]
    
    for pattern in numbered_definition_patterns:
        match = re.search(pattern, query.strip(), re.IGNORECASE)
        if match:
            query_type = "numbered_definition"
            extracted_number = match.group(1)
            user_query_term = match.group(2).strip()
            logger.info(f"Detected numbered definition: {extracted_number}. {user_query_term}")
            break
    
    # Pattern 2: Field lookup patterns with "what is", "define", etc.
    if query_type == "general":
        field_lookup_patterns = [
            r"(?:what\s+is|define|explain)\s+(.+?)(?:\?|$)",
            r"(?:tell\s+me\s+about|describe)\s+(.+?)(?:\?|$)",
            r"(?:meaning\s+of|definition\s+of)\s+(.+?)(?:\?|$)"
        ]
        
        for pattern in field_lookup_patterns:
            match = re.search(pattern, query, re.IGNORECASE)
            if match:
                query_type = "field_lookup"
                user_query_term = match.group(1).strip()
                
                # Remove number prefix if present
                number_match = re.match(r"^(\d+)\.\s*(.+)", user_query_term)
                if number_match:
                    extracted_number = number_match.group(1)
                    user_query_term = number_match.group(2).strip()
                    query_type = "numbered_definition"
                
                logger.info(f"Detected field lookup: {user_query_term}")
                break
    
    # Pattern 3: Direct technical terms (all caps with underscores)
    if query_type == "general":
        if re.match(r"^[A-Z][A-Z0-9_]+$", query.strip()):
            query_type = "field_lookup"
            user_query_term = query.strip()
            logger.info(f"Detected technical term: {user_query_term}")
    
    # Pattern 4: Try to extract field number from field references in the query
    if not extracted_number and query_type != "numbered_definition":
        potential_number = extract_field_number_from_definition(query)
        if potential_number:
            extracted_number = potential_number
            query_type = "numbered_definition"
            logger.info(f"Extracted field number {extracted_number} from query reference")
    
    # Pattern 5: Look up known field names to find their numbers
    if query_type == "field_lookup" and not extracted_number:
        potential_numbers = find_definition_by_name(user_query_term)
        if potential_numbers:
            extracted_number = potential_numbers[0]  # Take the first match
            query_type = "numbered_definition"
            logger.info(f"Found field number {extracted_number} for '{user_query_term}'")
    
    # Clean up the term
    user_query_term = user_query_term.strip('\'"').strip()
    
    return {
        **state,
        "user_query_term": user_query_term,
        "query_type": query_type,
        "extracted_number": extracted_number,
        "retry_count": 0,
        "confidence_score": 0.0
    }

# Enhanced Numbered Definition Retrieval Node
def numbered_definition_retrieval(state: RAGState) -> RAGState:
    """Enhanced retrieval specifically for numbered definitions with multiple search strategies"""
    query = state["query"]
    user_query_term = state["user_query_term"]
    extracted_number = state["extracted_number"]
    
    all_results = []
    seen_docs = set()
    
    # Strategy 1: If we have a number, use it for exact searches
    if extracted_number:
        search_queries = [
            f"{extracted_number}. {user_query_term}:",
            f"{extracted_number}. {user_query_term.upper()}:",
            f"{extracted_number}. {user_query_term.title()}:",
            f"{extracted_number}. {user_query_term}",
            f"**{extracted_number}. {user_query_term}**",
            f"Field #{extracted_number}",
            f"Field {extracted_number}"
        ]
    else:
        # Strategy 2: Search by name and try to find the number
        search_queries = [
            user_query_term,
            user_query_term.upper(),
            user_query_term.title(),
            f"Technical Name: {user_query_term}",
            f"Definition: {user_query_term}"
        ]
    
    # Strategy 3: Add variations for partial matches
    search_queries.extend([
        user_query_term.replace("Code", "").strip(),
        user_query_term.replace("HCFA", "").strip(),
        user_query_term.replace("Type", "").strip()
    ])
    
    # Remove duplicates while preserving order
    search_queries = list(dict.fromkeys([q for q in search_queries if q.strip()]))
    
    for search_query in search_queries:
        try:
            query_embedding = embeddings_service.embed_query(search_query)
            results = collection.query(
                query_embeddings=[query_embedding],
                n_results=5,
                include=["documents", "metadatas", "distances"]
            )
            
            if results and results.get('documents'):
                for i, doc in enumerate(results.get('documents', [[]])[0]):
                    if doc not in seen_docs:
                        seen_docs.add(doc)
                        metadata = results.get('metadatas', [[]])[0][i] if i < len(results.get('metadatas', [[]])[0]) else {}
                        distance = results.get('distances', [[]])[0][i] if i < len(results.get('distances', [[]])[0]) else 1.0
                        
                        # Check for exact numbered definition match
                        is_exact_match = False
                        found_number = None
                        
                        if extracted_number:
                            # Check for exact number match
                            exact_patterns = [
                                rf"^{extracted_number}\.\s*{re.escape(user_query_term)}:",
                                rf"\*\*{extracted_number}\.\s*{re.escape(user_query_term)}\*\*",
                                rf"{extracted_number}\.\s*\[{re.escape(user_query_term)}\]"
                            ]
                            
                            for pattern in exact_patterns:
                                if re.search(pattern, doc, re.IGNORECASE):
                                    is_exact_match = True
                                    found_number = extracted_number
                                    break
                        else:
                            # Try to extract number from the content
                            number_match = re.search(rf"(\d+)\.\s*{re.escape(user_query_term)}", doc, re.IGNORECASE)
                            if number_match:
                                found_number = number_match.group(1)
                                is_exact_match = True
                        
                        all_results.append({
                            'content': doc,
                            'metadata': metadata,
                            'distance': distance,
                            'is_exact_match': is_exact_match,
                            'found_number': found_number,
                            'retrieval_strategy': 'numbered_definition',
                            'search_query': search_query
                        })
                        
        except Exception as e:
            logger.error(f"Error in numbered definition search with query '{search_query}': {e}")
    
    # Sort by exact match first, then by distance
    all_results.sort(key=lambda x: (
        not x.get('is_exact_match', False),
        x['distance'],
        -len(x['content'])  # Prefer longer content for complete definitions
    ))
    
    # Update the extracted number if we found one
    if not extracted_number and all_results:
        top_result = all_results[0]
        if top_result.get('found_number'):
            state["extracted_number"] = top_result['found_number']
    
    return {
        **state,
        "retrieved_docs": all_results[:15],
        "retrieval_strategies": state.get("retrieval_strategies", []) + ["numbered_definition"]
    }

# Enhanced Field Lookup Retrieval Node
def field_lookup_retrieval(state: RAGState) -> RAGState:
    """Enhanced field lookup with better technical term matching"""
    user_query_term = state["user_query_term"]
    
    # Multiple search strategies for technical fields
    search_queries = [
        user_query_term,
        user_query_term.upper(),
        user_query_term.lower(),
        f"Technical Name: {user_query_term}",
        f"Technical Name: {user_query_term.upper()}",
        f"Field {user_query_term}",
        f"**{user_query_term}**",
        f"[{user_query_term}]"
    ]
    
    # Add variations for common technical name patterns
    if '_' in user_query_term:
        # For names like AHF_BFD_AMT, also search without underscores
        no_underscore = user_query_term.replace('_', ' ')
        search_queries.extend([
            no_underscore,
            no_underscore.title()
        ])
    
    all_results = []
    seen_docs = set()
    
    for search_query in search_queries:
        try:
            query_embedding = embeddings_service.embed_query(search_query)
            results = collection.query(
                query_embeddings=[query_embedding],
                n_results=5,
                include=["documents", "metadatas", "distances"]
            )
            
            if results and results.get('documents'):
                for i, doc in enumerate(results.get('documents', [[]])[0]):
                    if doc not in seen_docs:
                        seen_docs.add(doc)
                        metadata = results.get('metadatas', [[]])[0][i] if i < len(results.get('metadatas', [[]])[0]) else {}
                        distance = results.get('distances', [[]])[0][i] if i < len(results.get('distances', [[]])[0]) else 1.0
                        
                        # Check for technical name match
                        is_field_match = bool(re.search(rf"Technical Name:\s*{re.escape(user_query_term)}", doc, re.IGNORECASE))
                        
                        # Check for numbered definition containing this field
                        is_in_definition = bool(re.search(rf"\d+\.\s*.*{re.escape(user_query_term)}", doc, re.IGNORECASE))
                        
                        all_results.append({
                            'content': doc,
                            'metadata': metadata,
                            'distance': distance,
                            'is_field_match': is_field_match,
                            'is_in_definition': is_in_definition,
                            'retrieval_strategy': 'field_lookup',
                            'search_query': search_query
                        })
                        
        except Exception as e:
            logger.error(f"Error in field lookup search: {e}")
    
    # Sort by field match, then definition presence, then by distance
    all_results.sort(key=lambda x: (
        not x.get('is_field_match', False),
        not x.get('is_in_definition', False),
        x['distance']
    ))
    
    return {
        **state,
        "retrieved_docs": all_results[:15],
        "retrieval_strategies": state.get("retrieval_strategies", []) + ["field_lookup"]
    }

# Semantic Retrieval Node (unchanged but optimized)
def semantic_retrieval(state: RAGState) -> RAGState:
    """General semantic retrieval with enhanced query rewriting"""
    user_query_term = state["user_query_term"]
    query = state["query"]
    
    # Enhanced query rewriting for medical terminology
    rewrite_prompt = f"""
    Optimize the following query for semantic search in a medical data dictionary.
    Focus on medical terms, field names, and data definitions.
    
    Original query: "{query}"
    Core term: "{user_query_term}"
    
    Create an optimized search query that captures medical terminology and field definitions.
    Return only the optimized query.
    """
    
    try:
        optimized_query = chat_model.invoke(rewrite_prompt).content.strip()
        if not optimized_query:
            optimized_query = user_query_term
    except Exception as e:
        logger.error(f"Error in query rewriting: {e}")
        optimized_query = user_query_term
    
    # Perform semantic search
    try:
        query_embedding = embeddings_service.embed_query(optimized_query)
        results = collection.query(
            query_embeddings=[query_embedding],
            n_results=NUM_RETRIEVED_DOCS,
            include=["documents", "metadatas", "distances"]
        )
        
        retrieved_docs = []
        if results and results.get('documents'):
            for i, doc in enumerate(results.get('documents', [[]])[0]):
                metadata = results.get('metadatas', [[]])[0][i] if i < len(results.get('metadatas', [[]])[0]) else {}
                distance = results.get('distances', [[]])[0][i] if i < len(results.get('distances', [[]])[0]) else 1.0
                
                retrieved_docs.append({
                    'content': doc,
                    'metadata': metadata,
                    'distance': distance,
                    'retrieval_strategy': 'semantic'
                })
        
        return {
            **state,
            "retrieved_docs": retrieved_docs,
            "retrieval_strategies": state.get("retrieval_strategies", []) + ["semantic"]
        }
    
    except Exception as e:
        logger.error(f"Error in semantic retrieval: {e}")
        return {
            **state,
            "error_message": f"Semantic retrieval failed: {e}"
        }

# Enhanced Document Processing and Ranking Node
def process_and_rank_documents(state: RAGState) -> RAGState:
    """Enhanced document processing with better scoring for numbered definitions"""
    retrieved_docs = state["retrieved_docs"]
    user_query_term = state["user_query_term"]
    query = state["query"]
    query_type = state["query_type"]
    extracted_number = state["extracted_number"]
    
    if not retrieved_docs:
        return state
    
    processed_docs = []
    
    for doc in retrieved_docs:
        content = doc['content']
        metadata = doc['metadata']
        distance = doc['distance']
        
        # Initialize relevance score
        relevance_score = 0.0
        
        # 1. Exact numbered definition match (highest priority)
        if extracted_number:
            # Multiple exact match patterns
            exact_patterns = [
                rf"^{extracted_number}\.\s*{re.escape(user_query_term)}:",
                rf"\*\*{extracted_number}\.\s*{re.escape(user_query_term)}\*\*",
                rf"{extracted_number}\.\s*\[{re.escape(user_query_term)}\]{{.underline}}:",
                rf"^{extracted_number}\.\s*{re.escape(user_query_term)}\s*:"
            ]
            
            for pattern in exact_patterns:
                if re.search(pattern, content, re.IGNORECASE):
                    relevance_score += 150.0  # Very high score for exact matches
                    logger.info(f"  *** EXACT MATCH *** {extracted_number}. {user_query_term}")
                    break
        
        # 2. Check for any numbered definition of the term (even with different number)
        numbered_def_patterns = [
            rf"(\d+)\.\s*{re.escape(user_query_term)}:",
            rf"\*\*(\d+)\.\s*{re.escape(user_query_term)}\*\*",
            rf"(\d+)\.\s*\[{re.escape(user_query_term)}\]"
        ]
        
        for pattern in numbered_def_patterns:
            match = re.search(pattern, content, re.IGNORECASE)
            if match:
                found_number = match.group(1)
                if extracted_number and found_number == extracted_number:
                    relevance_score += 100.0  # Exact number match
                else:
                    relevance_score += 80.0   # Different number but same term
                break
        
        # 3. Technical name exact match
        if re.search(rf"Technical Name:\s*{re.escape(user_query_term)}", content, re.IGNORECASE):
            relevance_score += 90.0
        
        # 4. Term appears at the beginning of content
        if content.lower().strip().startswith(user_query_term.lower().strip()):
            relevance_score += 70.0
        
        # 5. Term appears in bold or emphasized text
        emphasis_patterns = [
            rf"\*\*{re.escape(user_query_term)}\*\*",
            rf"\[{re.escape(user_query_term)}\]",
            rf"^{re.escape(user_query_term)}:",
        ]
        
        for pattern in emphasis_patterns:
            if re.search(pattern, content, re.IGNORECASE):
                relevance_score += 60.0
                break
        
        # 6. Check for complete definition structure
        definition_elements = ['Format:', 'Technical Name:', 'Length:', 'Position', 'Definition:']
        element_count = sum(1 for element in definition_elements if element in content)
        relevance_score += element_count * 8.0
        
        # 7. Check metadata for definition completeness
        def_completeness = metadata.get("definition_completeness", 0)
        if isinstance(def_completeness, str) and def_completeness.isdigit():
            def_completeness = int(def_completeness)
        elif not isinstance(def_completeness, int):
            def_completeness = 0
        
        relevance_score += def_completeness * 5.0
        
        # 8. Metadata indicators
        if metadata.get("is_numbered_definition") == True:
            relevance_score += 30.0
        if metadata.get("is_complete_definition") == True:
            relevance_score += 25.0
        if metadata.get("is_field_spec") == True:
            relevance_score += 20.0
        
        # 9. Distance-based scoring (lower distance = higher score)
        distance_score = max(0, 25.0 * (1.0 - distance))
        relevance_score += distance_score
        
        # 10. Content quality indicators
        if 'appendix' in content.lower() and 'value' in content.lower():
            relevance_score += 15.0  # Bonus for value definitions
        
        # 11. Word match scoring
        if re.search(rf"\b{re.escape(user_query_term)}\b", content, re.IGNORECASE):
            relevance_score += 25.0
        
        # 12. Penalty for incomplete or very short content
        if len(content.strip()) < 100:
            relevance_score -= 10.0
        
        # 13. Bonus for retrieval strategy
        if doc.get('is_exact_match'):
            relevance_score += 50.0
        if doc.get('is_field_match'):
            relevance_score += 40.0
        
        processed_docs.append({
            **doc,
            'relevance_score': relevance_score,
            'quality_indicators': {
                'has_definition_structure': element_count >= 3,
                'is_complete': metadata.get("is_complete_definition", False),
                'content_length': len(content),
                'confidence': min(1.0, relevance_score / 150.0),
                'found_number': doc.get('found_number', extracted_number)
            }
        })
    
    # Sort by relevance score (descending)
    processed_docs.sort(key=lambda x: x['relevance_score'], reverse=True)
    
    # Calculate overall confidence
    top_score = processed_docs[0]['relevance_score'] if processed_docs else 0
    confidence_score = min(1.0, top_score / 150.0)
    
    # Log ranking information for debugging
    logger.info("\n--- Document Ranking Results ---")
    for i, doc in enumerate(processed_docs[:5]):
        metadata = doc['metadata']
        logger.info(f"{i+1}. Score: {doc['relevance_score']:.1f}, Distance: {doc['distance']:.3f}")
        logger.info(f"   Strategy: {doc.get('retrieval_strategy', 'unknown')}")
        logger.info(f"   Content preview: {doc['content'][:100]}...")
        if doc.get('found_number'):
            logger.info(f"   Found field number: {doc['found_number']}")
    
    return {
        **state,
        "processed_docs": processed_docs,
        "confidence_score": confidence_score
    }

# Enhanced Context Building Node
def build_context(state: RAGState) -> RAGState:
    """Build context with better formatting for numbered definitions"""
    processed_docs = state["processed_docs"]
    query_type = state["query_type"]
    extracted_number = state["extracted_number"]
    
    if not processed_docs:
        return {
            **state,
            "context_string": "No relevant information found.",
            "confidence_score": 0.0
        }
    
    # Filter documents by quality and relevance
    filtered_docs = [
        doc for doc in processed_docs 
        if doc['distance'] <= RETRIEVAL_DISTANCE_THRESHOLD and doc['relevance_score'] > 15.0
    ]
    
    if not filtered_docs:
        return {
            **state,
            "context_string": "No relevant information found matching quality criteria.",
            "confidence_score": 0.0
        }
    
    # For numbered definitions, prioritize exact matches
    if query_type == "numbered_definition" and extracted_number:
        exact_matches = [doc for doc in filtered_docs if doc.get('is_exact_match')]
        if exact_matches:
            filtered_docs = exact_matches[:3] + [d for d in filtered_docs if not d.get('is_exact_match')][:2]
    
    # Build context with detailed source attribution
    context_parts = []
    for i, doc in enumerate(filtered_docs[:5]):
        metadata = doc['metadata']
        content = doc['content']
        source = metadata.get('source_filename', 'Unknown source')
        page = metadata.get('page_number', 'N/A')
        element_type = metadata.get('element_type', 'text')
        relevance_score = doc['relevance_score']
        
        # Clean up the content for better presentation
        content = re.sub(r'\n+', '\n', content)
        content = content.strip()
        
        context_parts.append(
            f"[Source: {source}, Page: {page}, Type: {element_type}, Relevance: {relevance_score:.1f}]\n{content}"
        )
    
    context_string = "\n\n---\n\n".join(context_parts)
    
    return {
        **state,
        "context_string": context_string
    }

# Enhanced Answer Generation Node
def generate_answer(state: RAGState) -> RAGState:
    """Generate formatted answer matching the expected output format"""
    context_string = state["context_string"]
    query = state["query"]
    user_query_term = state["user_query_term"]
    query_type = state["query_type"]
    confidence_score = state["confidence_score"]
    extracted_number = state["extracted_number"]
    
    if not context_string or context_string == "No relevant information found.":
        return {
            **state,
            "final_answer": "I could not find relevant information for your query in the document.",
            "confidence_score": 0.0
        }
    
    # Enhanced prompt for numbered definitions
    if query_type == "numbered_definition":
        prompt_template = """You are an AI assistant that extracts numbered definitions from a medical data dictionary.

The user asked about: "{original_question}"
The specific term is: "{user_term}"
{number_info}

CRITICAL INSTRUCTIONS:
1. Find and reproduce the COMPLETE numbered definition EXACTLY as it appears
2. The format should be: **[NUMBER]. [TITLE]:**
3. Include ALL structured fields: Format, Technical Name, Length, Positions, Definition
4. Use bullet points (•) for each field
5. Preserve exact formatting, capitalization, and spacing
6. Include any notes or special information
7. If embedded tables or value definitions exist, include them

Expected format:
**[NUMBER]. [FIELD NAME]:**
• **Format:** [value]
• **Technical Name:** [value]  
• **Length:** [value]
• **Positions:** [value]
• **Definition:** [complete definition text]

[Any additional notes or tables]

Context from document:
---
{context}
---

Response (reproduce the exact numbered definition):"""
        
        number_info = f"Expected field number: {extracted_number}" if extracted_number else "Field number to be determined from context"
        
    else:
        prompt_template = """You are an AI assistant that explains fields from a medical data dictionary.

The user asked about: "{original_question}"
The term they're interested in: "{user_term}"

INSTRUCTIONS:
1. Find the complete definition for this term
2. Present it in the standard format with bullet points
3. Include all available information (Format, Technical Name, Length, etc.)
4. Preserve exact formatting from the source
5. Include any embedded tables or value definitions

Context from document:
---
{context}
---

Response (provide complete field information):"""
        number_info = ""
    
    # Generate the answer
    final_prompt = prompt_template.format(
        original_question=query,
        user_term=user_query_term,
        number_info=number_info,
        context=context_string
    )
    
    try:
        response = chat_model.invoke(final_prompt)
        final_answer = response.content.strip()
        
        # Post-process the answer to ensure proper formatting
        final_answer = post_process_answer(final_answer, query_type, extracted_number)
        
        # Adjust confidence based on answer quality
        if "could not find" in final_answer.lower() or "no information" in final_answer.lower():
            confidence_score *= 0.3
        elif extracted_number and f"{extracted_number}." in final_answer:
            confidence_score = min(1.0, confidence_score + 0.2)
        
        return {
            **state,
            "final_answer": final_answer,
            "confidence_score": confidence_score
        }
    
    except Exception as e:
        logger.error(f"Error generating answer: {e}")
        return {
            **state,
            "final_answer": f"Error generating response: {e}",
            "confidence_score": 0.0
        }

def post_process_answer(answer: str, query_type: str, extracted_number: Optional[str]) -> str:
    """Post-process the answer to ensure proper formatting"""
    if query_type != "numbered_definition":
        return answer
    
    # Ensure proper numbered definition format
    lines = answer.split('\n')
    processed_lines = []
    
    for line in lines:
        # Fix bullet point formatting
        line = re.sub(r'^[\s-]*([•\*])?[\s]*\*\*([^:]+):\*\*', r'• **\2:**', line)
        line = re.sub(r'^[\s-]*([•\*])?[\s]*([^:]+):', r'• **\2:**', line)
        
        processed_lines.append(line)
    
    processed_answer = '\n'.join(processed_lines)
    
    # Ensure the answer starts with the numbered definition if we have the number
    if extracted_number and not processed_answer.startswith('**'):
        # Try to find the definition line and make it the header
        for line in processed_lines:
            if f"{extracted_number}." in line and "**" in line:
                # Move this line to the top
                processed_lines.remove(line)
                processed_lines.insert(0, line)
                break
        processed_answer = '\n'.join(processed_lines)
    
    return processed_answer

# Rest of the nodes remain the same...
def validate_answer(state: RAGState) -> RAGState:
    """Validate the quality of the generated answer"""
    final_answer = state["final_answer"]
    query_type = state["query_type"]
    user_query_term = state["user_query_term"]
    confidence_score = state["confidence_score"]
    extracted_number = state["extracted_number"]
    
    validation_score = confidence_score
    
    # Enhanced validation for numbered definitions
    if query_type == "numbered_definition":
        # Check for numbered definition pattern
        if extracted_number and f"{extracted_number}." in final_answer:
            validation_score += 0.3
        if re.search(r'\d+\.\s*[^:]+:', final_answer):
            validation_score += 0.2
        
        # Check for complete definition structure
        definition_elements = ['Format:', 'Technical Name:', 'Length:', 'Position', 'Definition:']
        element_count = sum(1 for element in definition_elements if element in final_answer)
        validation_score += (element_count / len(definition_elements)) * 0.3
        
        # Check for proper formatting
        if '•' in final_answer or '*' in final_answer:
            validation_score += 0.1
    
    # General quality checks
    if len(final_answer) > 150:  # Substantial answer
        validation_score += 0.1
    if final_answer.count(':') >= 3:  # Well-structured information
        validation_score += 0.1
    
    # Cap the validation score
    validation_score = min(1.0, validation_score)
    
    return {
        **state,
        "confidence_score": validation_score
    }

def route_retrieval_strategy(state: RAGState) -> str:
    """Route to appropriate retrieval strategy"""
    query_type = state["query_type"]
    
    if query_type == "numbered_definition":
        return "numbered_definition"
    elif query_type == "field_lookup":
        return "field_lookup"
    else:
        return "semantic"

def route_validation(state: RAGState) -> str:
    """Determine if answer needs retry"""
    confidence_score = state["confidence_score"]
    retry_count = state["retry_count"]
    
    if confidence_score < 0.4 and retry_count < 2:
        return "retry"
    else:
        return "end"

def retry_with_fallback(state: RAGState) -> RAGState:
    """Retry with different strategy"""
    retry_count = state["retry_count"]
    query_type = state["query_type"]
    
    new_retry_count = retry_count + 1
    
    # Fallback strategy
    if query_type == "numbered_definition" and retry_count == 0:
        new_query_type = "field_lookup"
    elif query_type == "field_lookup" and retry_count == 0:
        new_query_type = "concept_search"
    else:
        new_query_type = "concept_search"
    
    logger.info(f"Retrying with strategy: {new_query_type} (attempt {new_retry_count})")
    
    return {
        **state,
        "query_type": new_query_type,
        "retry_count": new_retry_count,
        "retrieved_docs": [],
        "processed_docs": [],
        "context_string": "",
        "confidence_score": 0.0
    }

def fallback_rag_pipeline(state: RAGState) -> RAGState:
    """Fallback implementation when LangGraph is not available"""
    logger.info("Using fallback RAG pipeline...")
    
    # Execute pipeline steps
    state = analyze_query(state)
    
    query_type = state["query_type"]
    if query_type == "numbered_definition":
        state = numbered_definition_retrieval(state)
    elif query_type == "field_lookup":
        state = field_lookup_retrieval(state)
    else:
        state = semantic_retrieval(state)
    
    state = process_and_rank_documents(state)
    state = build_context(state)
    state = generate_answer(state)
    state = validate_answer(state)
    
    # Simple retry logic
    if state["confidence_score"] < 0.4 and state["retry_count"] < 1:
        logger.info("Low confidence, attempting retry...")
        state = retry_with_fallback(state)
        state = semantic_retrieval(state)
        state = process_and_rank_documents(state)
        state = build_context(state)
        state = generate_answer(state)
        state = validate_answer(state)
    
    return state

def create_rag_workflow() -> CompiledGraph:
    """Create the enhanced RAG workflow"""
    if not LANGGRAPH_AVAILABLE:
        logger.warning("LangGraph not available, using fallback")
        return FallbackGraph()
    
    workflow = StateGraph(RAGState)
    
    # Add all nodes
    workflow.add_node("analyze_query", analyze_query)
    workflow.add_node("numbered_definition_retrieval", numbered_definition_retrieval)
    workflow.add_node("field_lookup_retrieval", field_lookup_retrieval)
    workflow.add_node("semantic_retrieval", semantic_retrieval)
    workflow.add_node("process_and_rank", process_and_rank_documents)
    workflow.add_node("build_context", build_context)
    workflow.add_node("generate_answer", generate_answer)
    workflow.add_node("validate_answer", validate_answer)
    workflow.add_node("retry_with_fallback", retry_with_fallback)
    
    # Set entry point
    workflow.set_entry_point("analyze_query")
    
    # Add routing logic
    workflow.add_conditional_edges(
        "analyze_query",
        route_retrieval_strategy,
        {
            "numbered_definition": "numbered_definition_retrieval",
            "field_lookup": "field_lookup_retrieval",
            "semantic": "semantic_retrieval"
        }
    )
    
    # Connect retrieval to processing
    workflow.add_edge("numbered_definition_retrieval", "process_and_rank")
    workflow.add_edge("field_lookup_retrieval", "process_and_rank")
    workflow.add_edge("semantic_retrieval", "process_and_rank")
    
    # Continue pipeline
    workflow.add_edge("process_and_rank", "build_context")
    workflow.add_edge("build_context", "generate_answer")
    workflow.add_edge("generate_answer", "validate_answer")
    
    # Validation routing
    workflow.add_conditional_edges(
        "validate_answer",
        route_validation,
        {
            "retry": "retry_with_fallback",
            "end": END
        }
    )
    
    # Retry routing
    workflow.add_conditional_edges(
        "retry_with_fallback",
        route_retrieval_strategy,
        {
            "numbered_definition": "numbered_definition_retrieval",
            "field_lookup": "field_lookup_retrieval",
            "semantic": "semantic_retrieval"
        }
    )
    
    return workflow.compile()

# Initialize system
try:
    init_clients_rag()
    rag_workflow = create_rag_workflow()
    logger.info("Enhanced RAG workflow initialized successfully")
except Exception as e:
    logger.error(f"FATAL: Error during RAG initialization: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

@app.route('/')
def index_route(): 
    return render_template('chat.html')

@app.route('/chat_rag', methods=['POST']) 
def chat_handler_rag():
    """Enhanced chat handler with better numbered definition support"""
    if not rag_workflow:
        return jsonify({"error": "RAG workflow not initialized."}), 500

    data = request.get_json()
    user_query = data.get('query')
    model_name = data.get('model')
    
    if not user_query: 
        return jsonify({"error": "Query not provided"}), 400

    try:
        # Get appropriate chat model
        current_chat_model = get_chat_model(model_name)
        
        # Initialize state
        initial_state = RAGState(
            query=user_query,
            user_query_term="",
            query_type="general",
            extracted_number=None,
            retrieval_strategies=[],
            retrieved_docs=[],
            processed_docs=[],
            context_string="",
            final_answer="",
            confidence_score=0.0,
            retry_count=0,
            error_message=None
        )
        
        # Set the chat model globally
        global chat_model
        chat_model = current_chat_model
        
        # Run the workflow
        logger.info(f"Processing query with {model_name}: '{user_query}'")
        final_state = rag_workflow.invoke(initial_state)
        
        # Extract results
        final_answer = final_state.get("final_answer", "No answer generated")
        confidence_score = final_state.get("confidence_score", 0.0)
        retrieval_strategies = final_state.get("retrieval_strategies", [])
        query_type = final_state.get("query_type", "unknown")
        extracted_number = final_state.get("extracted_number")
        
        # Get source metadata
        source_metadata = []
        for doc in final_state.get("processed_docs", [])[:5]:
            metadata = doc.get("metadata", {})
            source_metadata.append({
                "source": metadata.get("source_filename", "Unknown"),
                "page": metadata.get("page_number", "N/A"),
                "type": metadata.get("element_type", "text"),
                "score": doc.get("relevance_score", 0.0),
                "distance": doc.get("distance", 1.0)
            })
        
        logger.info(f"Query processed successfully. Type: {query_type}, Confidence: {confidence_score:.2f}")
        if extracted_number:
            logger.info(f"Extracted field number: {extracted_number}")
        
        return jsonify({
            "answer": final_answer,
            "confidence_score": confidence_score,
            "retrieval_strategies": retrieval_strategies,
            "retrieved_sources_metadata": source_metadata,
            "query_type": query_type,
            "extracted_number": extracted_number,
            "model_used": model_name or CHAT_MODEL_NAME
        })

    except Exception as e:
        logger.error(f"Error processing query: {e}", exc_info=True)
        return jsonify({"error": "An internal error occurred. Please check server logs."}), 500

@app.route('/chat', methods=['POST'])
def chat_handler_fallback():
    return chat_handler_rag()

if __name__ == '__main__':
    logger.info("Starting Enhanced RAG Flask application...")
    logger.info(f"GOOGLE_CLOUD_PROJECT: {GCP_PROJECT_ID}")
    
    port = int(os.environ.get('PORT', 8080))
    logger.info(f"Starting server on port {port}")
    app.run(debug=True, host='0.0.0.0', port=port)
