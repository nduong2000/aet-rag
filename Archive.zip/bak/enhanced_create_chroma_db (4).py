# Enhanced create_chroma_db.py for medical data dictionary
# FIXED: Better processing for numbered definitions with underlined format

import os
import shutil
import re
from pathlib import Path
from langchain_community.document_loaders import (
    UnstructuredExcelLoader, 
    TextLoader,
    UnstructuredWordDocumentLoader,
    PyPDFLoader
)
from langchain_unstructured import UnstructuredLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_google_vertexai import VertexAIEmbeddings
from langchain.schema import Document
import chromadb
import logging
import json
from typing import List, Dict, Any, Optional, Tuple, Union
import pandas as pd
import numpy as np
from docx import Document as DocxDocument
from docx.table import Table as DocxTable

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Configuration
DOCUMENTS_DIR = "./documents" 
CHROMA_DB_DIR = "./chroma_db_data"
COLLECTION_NAME = "rag_collection"
EMBEDDING_MODEL_NAME = "text-embedding-005"

# Enhanced chunking for complete numbered definitions
CHUNK_SIZE = 4000  # Larger to keep definitions together
CHUNK_OVERLAP = 200  # Less overlap to avoid splitting definitions
MIN_DEFINITION_SIZE = 100  # Minimum size for definition chunks
MAX_DEFINITION_SIZE = 3500  # Maximum size before forced splitting

# Initialize Vertex AI Embeddings
try:
    embeddings = VertexAIEmbeddings(model_name=EMBEDDING_MODEL_NAME)
    logger.info(f"Successfully initialized VertexAIEmbeddings: {EMBEDDING_MODEL_NAME}")
except Exception as e:
    logger.error(f"Error initializing VertexAIEmbeddings: {e}")
    logger.info("Please ensure Google Cloud authentication and Vertex AI API access")
    exit(1)

def preprocess_text(text_content: str) -> str:
    """Enhanced text preprocessing preserving medical dictionary formatting"""
    if not text_content:
        return ""
    
    # Clean extra whitespace but preserve structure
    text_content = re.sub(r' +', ' ', text_content)
    text_content = re.sub(r'\n\s*\n\s*\n+', '\n\n', text_content)
    
    # Clean non-printable characters but keep medical symbols
    text_content = re.sub(r'[^\x20-\x7E\n\r\t•\-–\—\[\]{}]', ' ', text_content)
    
    # Preserve key medical dictionary formatting
    # Fix numbered definitions with underlined format
    text_content = re.sub(r'(\d+)\.\s*\[([^\]]+)\]\{[^}]*\}:\s*', r'\1. [\2]:', text_content)
    
    # Preserve bullet points and formatting
    text_content = re.sub(r'[•·]\s*', '• ', text_content)
    text_content = re.sub(r'\*\*([^*]+)\*\*', r'**\1**', text_content)
    
    return text_content.strip()

def detect_numbered_definition_boundaries(text: str) -> List[Tuple[int, int, str, str]]:
    """Detect numbered definition boundaries with improved pattern matching for medical dictionary"""
    boundaries = []
    
    # Enhanced patterns for numbered definitions including underlined format
    patterns = [
        r'(\d+)\.\s*\[([^\]]+)\]\{[^}]*\}:\s*',  # Underlined: "158. [Diagnosis Code 6]{.underline}:"
        r'(\d+)\.\s*\[([^\]]+)\]:',  # Bracketed: "158. [Diagnosis Code 6]:"
        r'\*\*(\d+)\.\s*\[([^\]]+)\]\*\*:?',  # Bold bracketed: "**158. [Diagnosis Code 6]**"
        r'(\d+)\.\s*([^:\[\n]+):\s*',  # Standard: "158. Diagnosis Code 6:"
        r'\*\*(\d+)\.\s*([^:*\[\n]+):\*\*',  # Bold: "**158. Diagnosis Code 6:**"
    ]
    
    all_matches = []
    
    for pattern in patterns:
        matches = list(re.finditer(pattern, text, re.IGNORECASE))
        for match in matches:
            start_pos = match.start()
            definition_number = match.group(1)
            definition_title = match.group(2).strip()
            
            # Clean up title by removing extra formatting
            definition_title = re.sub(r'\{[^}]*\}', '', definition_title)
            definition_title = definition_title.strip('[]')
            
            all_matches.append((start_pos, definition_number, definition_title, match.group(0)))
    
    # Sort by position and remove duplicates
    all_matches.sort(key=lambda x: x[0])
    
    # Remove overlapping matches (keep the first one found)
    final_matches = []
    last_end = -1
    
    for start_pos, number, title, full_match in all_matches:
        if start_pos > last_end:
            final_matches.append((start_pos, number, title, full_match))
            last_end = start_pos + len(full_match)
    
    # Convert to boundaries with end positions
    for i, (start_pos, number, title, full_match) in enumerate(final_matches):
        # Find the end of this definition - look for next numbered definition
        if i + 1 < len(final_matches):
            end_pos = final_matches[i + 1][0]
        else:
            # Look for next major section starting with new number or end of text
            next_section = None
            search_start = start_pos + len(full_match)
            
            # Look for next numbered definition
            next_num_pattern = r'\n\s*\d+\.\s*'
            next_section = re.search(next_num_pattern, text[search_start:])
            
            if next_section:
                end_pos = search_start + next_section.start()
            else:
                # Look for major content break
                next_break = re.search(r'\n\n[A-Z]', text[search_start:])
                if next_break:
                    end_pos = search_start + next_break.start()
                else:
                    end_pos = len(text)
        
        boundaries.append((start_pos, end_pos, f"{number}. {title}", number))
    
    return boundaries

def analyze_content_patterns_advanced(text: str) -> Dict[str, Any]:
    """Advanced content pattern analysis for medical dictionary"""
    patterns = {}
    
    # 1. Numbered definitions (enhanced detection for underlined format)
    numbered_def_patterns = [
        r'(\d+)\.\s*\[([^\]]+)\]\{[^}]*\}:',  # "158. [Diagnosis Code 6]{.underline}:"
        r'(\d+)\.\s*\[([^\]]+)\]:',  # "158. [Diagnosis Code 6]:"
        r'(\d+)\.\s*([^:\[\n]+):',  # "158. Diagnosis Code 6:"
        r'\*\*(\d+)\.\s*([^:*\n]+):\*\*',  # "**158. Diagnosis Code 6:**"
    ]
    
    all_numbered_defs = []
    for pattern in numbered_def_patterns:
        matches = re.findall(pattern, text, re.IGNORECASE)
        # Clean up matches
        cleaned_matches = []
        for match in matches:
            number = match[0]
            title = match[1].strip('[]{}')
            title = re.sub(r'\{[^}]*\}', '', title)  # Remove underline markup
            cleaned_matches.append((number, title))
        all_numbered_defs.extend(cleaned_matches)
    
    # Remove duplicates and sort
    unique_defs = list(set(all_numbered_defs))
    patterns['numbered_definitions'] = unique_defs
    patterns['definition_count'] = len(unique_defs)
    
    # Extract definition numbers for reference
    definition_numbers = sorted(set([match[0] for match in unique_defs if match[0].isdigit()]))
    patterns['definition_numbers'] = definition_numbers
    
    # 2. Technical names (enhanced patterns)
    tech_name_patterns = [
        r'[•\-]\s*\*\*Technical Name:\*\*\s*([A-Z_][A-Z0-9_\(\)\s]*)',
        r'Technical Name:\s*([A-Z_][A-Z0-9_\(\)\s]*)',
        r'\*\*Technical Name:\*\*\s*([A-Z_][A-Z0-9_\(\)\s]*)',
    ]
    
    technical_names = []
    for pattern in tech_name_patterns:
        matches = re.findall(pattern, text)
        technical_names.extend([name.strip() for name in matches])
    
    patterns['technical_names'] = list(set(technical_names))
    
    # 3. Field specifications with bullet points
    field_elements = {
        'formats': re.findall(r'[•\-]\s*\*\*Format:\*\*\s*([^\n]+)', text),
        'lengths': re.findall(r'[•\-]\s*\*\*Length:\*\*\s*(\d+)', text),
        'positions': re.findall(r'[•\-]\s*\*\*Position[s]?:\*\*\s*([\d\s\-–—,]+)', text),
        'definitions': re.findall(r'[•\-]\s*\*\*Definition:\*\*\s*([^\n]+)', text)
    }
    
    patterns.update(field_elements)
    
    # 4. Content classification
    content_type = 'descriptive_text'  # Default
    
    if unique_defs:
        if len(unique_defs) == 1:
            content_type = 'single_numbered_definition'
        else:
            content_type = 'multiple_numbered_definitions'
    elif technical_names and any(field_elements.values()):
        content_type = 'field_specification'
    
    patterns['content_type'] = content_type
    
    # 5. Quality indicators
    patterns['has_complete_structure'] = (
        len(field_elements['formats']) > 0 and
        len(patterns['technical_names']) > 0 and
        len(field_elements['definitions']) > 0
    )
    
    patterns['completeness_score'] = sum([
        1 if field_elements['formats'] else 0,
        1 if patterns['technical_names'] else 0,
        1 if field_elements['lengths'] else 0,
        1 if field_elements['positions'] else 0,
        1 if field_elements['definitions'] else 0
    ])
    
    return patterns

def create_enhanced_metadata(doc: Document, patterns: Dict, tables: List[Dict], file_path: str, chunk_info: Dict = None) -> Dict:
    """Create comprehensive metadata for ChromaDB"""
    metadata = {
        'source_filename': os.path.basename(file_path),
        'content_length': len(doc.page_content),
        'content_type': patterns.get('content_type', 'unknown'),
    }
    
    # Add original document metadata
    if hasattr(doc, 'metadata') and doc.metadata:
        metadata.update({
            'page_number': str(doc.metadata.get('page_number', 'N/A')),
            'element_type': doc.metadata.get('category', doc.metadata.get('element_type', 'Unknown')),
        })
    else:
        metadata.update({
            'page_number': 'N/A',
            'element_type': 'Unknown',
        })
    
    # Chunk information
    if chunk_info:
        metadata.update(chunk_info)
    
    # Numbered definition metadata
    numbered_defs = patterns.get('numbered_definitions', [])
    if numbered_defs:
        definition_numbers = [def_info[0] for def_info in numbered_defs]
        definition_titles = [def_info[1] for def_info in numbered_defs]
        
        metadata['definition_numbers'] = ','.join(definition_numbers)
        metadata['definition_titles'] = ','.join(definition_titles)
        metadata['is_numbered_definition'] = True
        metadata['definition_count'] = len(numbered_defs)
        
        # Single definition metadata
        if len(numbered_defs) == 1:
            metadata['definition_number'] = definition_numbers[0]
            metadata['definition_title'] = definition_titles[0] if definition_titles else ''
    else:
        metadata['is_numbered_definition'] = False
        metadata['definition_count'] = 0
    
    # Technical name metadata
    technical_names = patterns.get('technical_names', [])
    if technical_names:
        metadata['technical_names'] = ','.join(technical_names)
        metadata['is_field_spec'] = True
        
        if len(technical_names) == 1:
            metadata['primary_technical_name'] = technical_names[0]
    else:
        metadata['is_field_spec'] = False
    
    # Field specification elements
    field_elements = ['formats', 'lengths', 'positions', 'definitions']
    for element in field_elements:
        values = patterns.get(element, [])
        if values:
            metadata[f'{element[:-1]}_info'] = ','.join(str(v) for v in values[:3])
    
    # Content quality and completeness
    completeness_score = patterns.get('completeness_score', 0)
    metadata['definition_completeness'] = completeness_score
    metadata['is_complete_definition'] = completeness_score >= 4
    
    # Search optimization metadata
    searchable_terms = []
    
    # Add numbered definition terms
    if numbered_defs:
        for number, title in numbered_defs:
            searchable_terms.extend([
                f"{number}. {title}",
                f"{number}. [{title}]",
                title.upper(),
                title.lower(),
                number
            ])
    
    # Add technical names
    if technical_names:
        searchable_terms.extend(technical_names)
    
    # Limit searchable terms for ChromaDB constraints
    if searchable_terms:
        unique_terms = list(dict.fromkeys(searchable_terms))
        metadata['searchable_terms'] = ','.join(unique_terms[:15])
    
    # Ensure all metadata values are ChromaDB compatible
    for key, value in metadata.items():
        if isinstance(value, (list, tuple)):
            metadata[key] = ','.join(str(v) for v in value)
        elif not isinstance(value, (str, int, float, bool, type(None))):
            metadata[key] = str(value)
        elif value is None:
            metadata[key] = ''
        elif isinstance(value, str) and len(value) > 500:
            metadata[key] = value[:500] + '...'
    
    return metadata

def smart_chunk_numbered_definitions(text: str, text_splitter: RecursiveCharacterTextSplitter) -> List[Document]:
    """Intelligently chunk text keeping complete numbered definitions together"""
    boundaries = detect_numbered_definition_boundaries(text)
    chunks = []
    
    if not boundaries:
        # No numbered definitions found, use standard chunking
        return text_splitter.create_documents([text])
    
    logger.info(f"Found {len(boundaries)} numbered definitions to preserve")
    
    current_pos = 0
    
    for start_pos, end_pos, definition_title, definition_number in boundaries:
        # Add any text before the definition
        if current_pos < start_pos:
            pre_text = text[current_pos:start_pos].strip()
            if pre_text and len(pre_text) > MIN_DEFINITION_SIZE:
                pre_chunks = text_splitter.create_documents([pre_text])
                chunks.extend(pre_chunks)
        
        # Extract the complete definition
        definition_text = text[start_pos:end_pos].strip()
        
        # Always keep the complete definition together as one chunk
        # even if it's longer than normal chunk size
        chunk_doc = Document(
            page_content=definition_text,
            metadata={
                'chunk_type': 'complete_definition',
                'definition_number': definition_number,
                'definition_title': definition_title.replace(f"{definition_number}. ", ""),
                'start_pos': start_pos,
                'end_pos': end_pos,
                'is_numbered_definition': True
            }
        )
        chunks.append(chunk_doc)
        logger.info(f"Preserved complete definition: {definition_number}. {len(definition_text)} chars")
        
        current_pos = end_pos
    
    # Add any remaining text
    if current_pos < len(text):
        remaining_text = text[current_pos:].strip()
        if remaining_text and len(remaining_text) > MIN_DEFINITION_SIZE:
            remaining_chunks = text_splitter.create_documents([remaining_text])
            chunks.extend(remaining_chunks)
    
    logger.info(f"Created {len(chunks)} total chunks")
    return chunks

def load_document_with_comprehensive_extraction(file_path: str) -> List[Document]:
    """Load document preserving numbered definitions and structure"""
    extension = os.path.splitext(file_path)[1].lower()
    documents = []
    
    logger.info(f"Loading document: {file_path} ({extension})")
    
    try:
        if extension == ".docx":
            # Use unstructured loader to get elements
            loader = UnstructuredWordDocumentLoader(file_path, mode="elements")
            raw_docs = loader.load()
            
        elif extension == ".doc":
            loader = UnstructuredLoader(file_path, mode="elements", strategy="auto")
            raw_docs = loader.load()
            
        elif extension in [".xlsx", ".xls"]:
            return load_excel_comprehensive(file_path)
            
        elif extension == ".pdf":
            loader = PyPDFLoader(file_path)
            raw_docs = loader.load()
            
        elif extension == ".txt":
            loader = TextLoader(file_path, encoding="utf-8")
            raw_docs = loader.load()
            
        else:
            logger.warning(f"Unsupported file type: {extension}")
            return documents
        
        # Combine all content first
        combined_content = ""
        for doc in raw_docs:
            processed_content = preprocess_text(doc.page_content)
            if len(processed_content.strip()) >= MIN_DEFINITION_SIZE:
                combined_content += processed_content + "\n\n"
        
        if not combined_content.strip():
            logger.warning(f"No content extracted from {file_path}")
            return documents
        
        # Analyze the combined content
        patterns = analyze_content_patterns_advanced(combined_content)
        
        # Create main document
        main_doc = Document(
            page_content=combined_content.strip(),
            metadata={
                'source_filename': os.path.basename(file_path),
                'element_type': 'combined_content',
                'page_number': 'combined',
            }
        )
        
        # Create enhanced metadata
        enhanced_metadata = create_enhanced_metadata(main_doc, patterns, [], file_path)
        main_doc.metadata = enhanced_metadata
        
        documents.append(main_doc)
        
        # Log what we found
        if patterns.get('numbered_definitions'):
            logger.info(f"  Found numbered definitions: {patterns['definition_numbers']}")
    
    except Exception as e:
        logger.error(f"Error loading {file_path}: {e}")
        import traceback
        traceback.print_exc()
    
    logger.info(f"Loaded {len(documents)} documents from {file_path}")
    return documents

def load_excel_comprehensive(file_path: str) -> List[Document]:
    """Process Excel files"""
    documents = []
    
    try:
        excel_file = pd.ExcelFile(file_path)
        
        for sheet_name in excel_file.sheet_names:
            try:
                df = pd.read_excel(file_path, sheet_name=sheet_name)
                
                if df.empty:
                    continue
                
                # Convert DataFrame to text
                content_lines = [f"**Sheet: {sheet_name}**", ""]
                
                # Add headers
                headers = df.columns.tolist()
                content_lines.append("**Columns:**")
                content_lines.append(" | ".join(str(col) for col in headers))
                content_lines.append("-" * len(" | ".join(str(col) for col in headers)))
                content_lines.append("")
                
                # Add data rows
                content_lines.append("**Data:**")
                for idx, row in df.head(50).iterrows():
                    row_text = " | ".join(str(val) if pd.notna(val) else "" for val in row.values)
                    content_lines.append(row_text)
                
                sheet_content = "\n".join(content_lines)
                
                sheet_doc = Document(
                    page_content=sheet_content,
                    metadata={
                        'source_filename': os.path.basename(file_path),
                        'sheet_name': sheet_name,
                        'element_type': 'excel_sheet',
                        'is_table_content': True,
                        'row_count': len(df),
                        'column_count': len(df.columns)
                    }
                )
                
                documents.append(sheet_doc)
                
            except Exception as e:
                logger.warning(f"Could not process sheet {sheet_name}: {e}")
    
    except Exception as e:
        logger.error(f"Error processing Excel file {file_path}: {e}")
    
    return documents

def load_all_documents(source_dir: str) -> List[Document]:
    """Load all documents from source directory"""
    all_documents = []
    
    if not os.path.exists(source_dir):
        logger.error(f"Source directory '{source_dir}' not found")
        return all_documents
    
    supported_extensions = {'.docx', '.doc', '.xlsx', '.xls', '.pdf', '.txt'}
    
    for filename in os.listdir(source_dir):
        if filename.startswith('.'):
            continue
        
        file_path = os.path.join(source_dir, filename)
        extension = os.path.splitext(filename)[1].lower()
        
        if extension in supported_extensions and os.path.isfile(file_path):
            docs = load_document_with_comprehensive_extraction(file_path)
            all_documents.extend(docs)
    
    logger.info(f"Total documents loaded: {len(all_documents)}")
    return all_documents

def create_optimized_chunks(documents: List[Document]) -> List[Document]:
    """Create optimized chunks preserving complete numbered definitions"""
    # Use larger separators to avoid breaking definitions
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=CHUNK_SIZE,
        chunk_overlap=CHUNK_OVERLAP,
        length_function=len,
        separators=[
            "\n\n\n",    # Major section breaks
            "\n\n",      # Paragraph breaks
            "\n",        # Line breaks
            " ",         # Word boundaries
            ""           # Character level
        ]
    )
    
    final_chunks = []
    
    for doc in documents:
        content_type = doc.metadata.get('content_type', '')
        
        # Use smart chunking for documents with numbered definitions
        if content_type in ['single_numbered_definition', 'multiple_numbered_definitions'] or doc.metadata.get('is_numbered_definition'):
            definition_chunks = smart_chunk_numbered_definitions(doc.page_content, text_splitter)
            
            for i, chunk in enumerate(definition_chunks):
                # Preserve and enhance metadata
                chunk.metadata.update(doc.metadata)
                chunk.metadata.update({
                    'chunk_index': i,
                    'total_chunks': len(definition_chunks),
                    'chunk_strategy': 'smart_numbered_definition'
                })
                final_chunks.append(chunk)
                
        else:
            # Standard chunking for other content
            chunks = text_splitter.split_documents([doc])
            
            for i, chunk in enumerate(chunks):
                chunk.metadata.update({
                    'chunk_index': i,
                    'total_chunks': len(chunks),
                    'chunk_strategy': 'standard_recursive'
                })
                final_chunks.append(chunk)
    
    return final_chunks

def analyze_final_collection(documents: List[Document]) -> Dict[str, Any]:
    """Analyze the final document collection"""
    analysis = {
        'total_documents': len(documents),
        'numbered_definitions': 0,
        'complete_definitions': 0,
        'content_types': {},
        'chunk_strategies': {},
        'definition_numbers': set(),
        'quality_metrics': {}
    }
    
    for doc in documents:
        metadata = doc.metadata
        
        # Count different types
        if metadata.get('is_numbered_definition'):
            analysis['numbered_definitions'] += 1
            
            if metadata.get('definition_number'):
                analysis['definition_numbers'].add(metadata['definition_number'])
        
        if metadata.get('is_complete_definition'):
            analysis['complete_definitions'] += 1
        
        # Track content types
        content_type = metadata.get('content_type', 'unknown')
        analysis['content_types'][content_type] = analysis['content_types'].get(content_type, 0) + 1
        
        # Track chunk strategies
        chunk_strategy = metadata.get('chunk_strategy', 'unknown')
        analysis['chunk_strategies'][chunk_strategy] = analysis['chunk_strategies'].get(chunk_strategy, 0) + 1
    
    # Calculate quality metrics
    analysis['quality_metrics'] = {
        'definition_coverage': len(analysis['definition_numbers']),
        'complete_definition_ratio': analysis['complete_definitions'] / max(analysis['numbered_definitions'], 1)
    }
    
    # Convert sets to lists for JSON serialization
    analysis['definition_numbers'] = sorted(list(analysis['definition_numbers']))
    
    return analysis

def main():
    """Main function to create enhanced ChromaDB"""
    logger.info("Starting enhanced ChromaDB creation...")
    logger.info("FIXED: Better handling of numbered definitions with underlined format")
    
    # Clean existing database
    if os.path.exists(CHROMA_DB_DIR):
        logger.info(f"Removing existing ChromaDB at {CHROMA_DB_DIR}")
        shutil.rmtree(CHROMA_DB_DIR)
    
    os.makedirs(CHROMA_DB_DIR, exist_ok=True)
    
    # Load and process documents
    logger.info("Loading documents...")
    documents = load_all_documents(DOCUMENTS_DIR)
    
    if not documents:
        logger.error("No documents loaded. Check source directory and file formats.")
        return
    
    # Create optimized chunks
    logger.info("Creating optimized chunks...")
    chunked_docs = create_optimized_chunks(documents)
    
    # Analyze the collection
    analysis = analyze_final_collection(chunked_docs)
    
    # Log analysis results
    logger.info("\n=== COLLECTION ANALYSIS ===")
    logger.info(f"Total chunks: {analysis['total_documents']}")
    logger.info(f"Numbered definitions: {analysis['numbered_definitions']}")
    logger.info(f"Complete definitions: {analysis['complete_definitions']}")
    logger.info(f"Definition coverage: {analysis['quality_metrics']['definition_coverage']} unique numbers")
    
    # Check if we found field 158
    if '158' in analysis['definition_numbers']:
        logger.info("✓ Found definition 158 (Diagnosis Code 6)")
    else:
        logger.warning("✗ Definition 158 (Diagnosis Code 6) not found")
    
    logger.info("\nContent Types:")
    for content_type, count in analysis['content_types'].items():
        logger.info(f"  {content_type}: {count}")
    
    # Prepare data for ChromaDB
    ids = [f"doc_{i}" for i in range(len(chunked_docs))]
    contents = [doc.page_content for doc in chunked_docs]
    metadatas = [doc.metadata for doc in chunked_docs]
    
    # Generate embeddings
    logger.info("Generating embeddings...")
    try:
        embeddings_list = embeddings.embed_documents(contents)
        logger.info(f"Generated {len(embeddings_list)} embeddings")
    except Exception as e:
        logger.error(f"Error generating embeddings: {e}")
        return
    
    # Initialize ChromaDB and add documents
    logger.info("Storing in ChromaDB...")
    try:
        client = chromadb.PersistentClient(path=CHROMA_DB_DIR)
        collection = client.get_or_create_collection(name=COLLECTION_NAME)
        
        # Add documents in batches
        batch_size = 500
        for i in range(0, len(ids), batch_size):
            end_idx = min(i + batch_size, len(ids))
            batch_ids = ids[i:end_idx]
            batch_embeddings = embeddings_list[i:end_idx]
            batch_contents = contents[i:end_idx]
            batch_metadatas = metadatas[i:end_idx]
            
            collection.add(
                ids=batch_ids,
                embeddings=batch_embeddings,
                documents=batch_contents,
                metadatas=batch_metadatas
            )
            
            logger.info(f"Added batch {i//batch_size + 1}: {len(batch_ids)} documents")
        
        # Verify final count
        final_count = collection.count()
        logger.info(f"Final collection size: {final_count} documents")
        
        # Test specific queries
        logger.info("Testing key queries...")
        
        test_queries = [
            "158. Diagnosis Code 6",
            "Diagnosis Code 6", 
            "[Diagnosis Code 6]",
            "ICD9_DX_CD (6)"
        ]
        
        for query in test_queries:
            test_embedding = embeddings.embed_query(query)
            test_results = collection.query(
                query_embeddings=[test_embedding],
                n_results=3,
                include=["documents", "metadatas", "distances"]
            )
            
            if test_results and test_results.get('documents'):
                logger.info(f"\nTest query: '{query}'")
                first_result = test_results['documents'][0][0]
                first_metadata = test_results.get('metadatas', [[]])[0][0] if test_results.get('metadatas') else {}
                distance = test_results.get('distances', [[]])[0][0] if test_results.get('distances') else 1.0
                
                logger.info(f"  Distance: {distance:.4f}")
                logger.info(f"  Content preview: {first_result[:200]}...")
                
                if first_metadata.get('definition_number') == '158':
                    logger.info("  ✓ Found correct definition 158!")
        
        logger.info("\n=== SUCCESS ===")
        logger.info("Enhanced ChromaDB created successfully!")
        logger.info(f"Ready to handle queries for numbered definitions")
        
    except Exception as e:
        logger.error(f"Error creating ChromaDB: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    if not os.path.exists(DOCUMENTS_DIR):
        logger.error(f"Documents directory '{DOCUMENTS_DIR}' not found")
        logger.info("Please create the directory and add your documents")
        os.makedirs(DOCUMENTS_DIR, exist_ok=True)
    elif not os.listdir(DOCUMENTS_DIR):
        logger.warning(f"Documents directory '{DOCUMENTS_DIR}' is empty")
        logger.info("Please add document files to this directory")
    else:
        main()