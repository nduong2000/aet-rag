# Enhanced create_chroma_db.py with comprehensive data type optimization
# Optimized for all data types in the universal medical/dental data dictionary

import os
import shutil
import re
from langchain_community.document_loaders import (
    UnstructuredExcelLoader, 
    TextLoader,
)
from langchain_unstructured import UnstructuredLoader 
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_google_vertexai import VertexAIEmbeddings
import chromadb
import logging

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# --- Configuration ---
DOCUMENTS_DIR = "./documents" 
CHROMA_DB_DIR = "./chroma_db_data"
COLLECTION_NAME = "rag_collection"
EMBEDDING_MODEL_NAME = "text-embedding-005"

# --- Enhanced Chunking Strategy for Multiple Data Types ---
CHUNK_SIZE = 1500  # Increased for better context
CHUNK_OVERLAP = 300  # Increased overlap for better continuity

# --- Initialize Vertex AI Embeddings ---
try:
    embeddings = VertexAIEmbeddings(model_name=EMBEDDING_MODEL_NAME)
    logger.info(f"Successfully initialized VertexAIEmbeddings with model: {EMBEDDING_MODEL_NAME}")
except Exception as e:
    logger.error(f"Error initializing VertexAIEmbeddings: {e}")
    logger.info("Please ensure you have authenticated with Google Cloud")
    logger.info("and the Vertex AI API is enabled in your project.")
    exit()

def preprocess_text(text_content):
    """Enhanced text preprocessing for medical documentation"""
    if not text_content:
        return ""
    
    # Normalize whitespace
    text_content = re.sub(r' +', ' ', text_content)
    text_content = re.sub(r'\n+', '\n', text_content)
    
    # Clean up common formatting issues
    text_content = re.sub(r'[^\x00-\x7F]+', ' ', text_content)  # Remove non-ASCII
    text_content = text_content.strip()
    
    return text_content

def detect_comprehensive_patterns(text_content):
    """Detect all types of data patterns in the medical dictionary"""
    patterns = {
        # Numbered definitions (141. HCFA Admit Type Code:)
        'numbered_definition': r'^\s*(\d+)\.\s*([^:\n]+):\s*',
        
        # Field definitions with technical names
        'technical_field': r'Technical Name:\s*([A-Z_][A-Z0-9_]*)',
        
        # Data format specifications
        'format_spec': r'Format:\s*(.+?)(?=\n|$)',
        'length_spec': r'Length:\s*(\d+(?:\.\d+)?)',
        'position_spec': r'Position[s]?:\s*(\d+(?:\s*-\s*\d+)?)',
        
        # Definition text
        'definition_text': r'Definition:\s*(.+?)(?=\n\*|$)',
        
        # Value definitions and mappings
        'value_mapping': r'(\w+)\s*=\s*(.+?)(?=\n|\s*$)',
        
        # Table headers and sections
        'table_header': r'\*\*([^*]+)\*\*',
        'section_header': r'^([A-Z][A-Z\s]+):?\s*$',
        
        # Code listings and appendices
        'code_listing': r'^\s*([A-Z0-9]+)\s+(.+)$',
        
        # Special field types
        'filler_field': r'Filler.*?Length:\s*(\d+)',
        'reserved_field': r'Reserved for future use',
        
        # Cross-references
        'appendix_ref': r'refer to.*?appendix|see.*?appendix',
        'field_ref': r'field\s*#?\s*(\d+)',
        
        # Data type indicators
        'signed_field': r'signed.*?implied decimal',
        'character_field': r'Format:\s*Character',
        'numeric_field': r'Format:\s*(?:Numeric|Decimal)',
        'date_field': r'Format:\s*Date',
        
        # Hierarchical structures
        'hierarchy_level': r'Hierarchy Level\s*(\d+)',
        
        # Special value indicators
        'valid_values': r'Valid values?\s*(?:are|:)\s*(.+)',
        'example_values': r'(?:Examples?|e\.g\.)[:\s]*(.+)',
    }
    
    found_patterns = {}
    for pattern_name, pattern in patterns.items():
        matches = re.findall(pattern, text_content, re.MULTILINE | re.IGNORECASE)
        if matches:
            found_patterns[pattern_name] = matches
    
    return found_patterns

def classify_content_type(text_content, detected_patterns):
    """Classify the type of content for better indexing"""
    content_types = []
    
    # Check for numbered definitions
    if detected_patterns.get('numbered_definition'):
        content_types.append('numbered_definition')
    
    # Check for field specifications
    if any(key in detected_patterns for key in ['technical_field', 'format_spec', 'length_spec']):
        content_types.append('field_specification')
    
    # Check for value mappings
    if detected_patterns.get('value_mapping'):
        content_types.append('value_mapping')
    
    # Check for appendices content
    if any(keyword in text_content.lower() for keyword in ['appendix', 'values and definitions']):
        content_types.append('appendix')
    
    # Check for table content
    if detected_patterns.get('code_listing') or len(detected_patterns.get('value_mapping', [])) > 3:
        content_types.append('lookup_table')
    
    # Check for hierarchical content
    if detected_patterns.get('hierarchy_level'):
        content_types.append('hierarchy_definition')
    
    # Check for explanatory content
    if 'definition:' in text_content.lower() or 'explanation' in text_content.lower():
        content_types.append('explanation')
    
    # Default classification
    if not content_types:
        if len(text_content) > 500:
            content_types.append('descriptive_text')
        else:
            content_types.append('short_text')
    
    return content_types

def extract_key_entities(text_content, detected_patterns):
    """Extract key entities and terms from the content"""
    entities = {
        'field_numbers': [],
        'technical_names': [],
        'abbreviations': [],
        'concepts': [],
        'values': []
    }
    
    # Extract field numbers
    if detected_patterns.get('numbered_definition'):
        for match in detected_patterns['numbered_definition']:
            entities['field_numbers'].append(match[0])
    
    # Extract technical names
    if detected_patterns.get('technical_field'):
        for match in detected_patterns['technical_field']:
            entities['technical_names'].append(match)
    
    # Extract abbreviations (uppercase terms)
    abbreviations = re.findall(r'\b[A-Z]{2,10}\b', text_content)
    entities['abbreviations'] = list(set(abbreviations))
    
    # Extract key concepts (capitalized terms)
    concepts = re.findall(r'\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\b', text_content)
    entities['concepts'] = list(set([c for c in concepts if len(c) > 3]))
    
    # Extract valid values
    if detected_patterns.get('value_mapping'):
        for match in detected_patterns['value_mapping']:
            entities['values'].append(match[0])
    
    return entities

def create_enhanced_metadata(element, file_path, content_types, detected_patterns, key_entities):
    """Create comprehensive metadata for each document element"""
    base_metadata = element.metadata.copy() if hasattr(element, 'metadata') else {}
    
    # Basic metadata
    enhanced_metadata = {
        'source_filename': os.path.basename(file_path),
        'page_number': str(base_metadata.get('page_number', 'N/A')),
        'element_type': base_metadata.get('category', 'Unknown'),
        'content_length': len(element.page_content),
        'content_types': ','.join(content_types),  # Convert list to comma-separated string
    }
    
    # Pattern-based metadata
    enhanced_metadata['detected_patterns'] = ','.join(detected_patterns.keys())  # Convert to string
    enhanced_metadata['pattern_count'] = len(detected_patterns)
    
    # Numbered definition metadata
    if 'numbered_definition' in content_types:
        numbered_match = detected_patterns.get('numbered_definition', [])
        if numbered_match:
            enhanced_metadata['definition_number'] = str(numbered_match[0][0])
            enhanced_metadata['definition_title'] = numbered_match[0][1].strip()
            enhanced_metadata['is_numbered_definition'] = True
        else:
            enhanced_metadata['is_numbered_definition'] = False
    else:
        enhanced_metadata['is_numbered_definition'] = False
    
    # Field specification metadata
    if 'field_specification' in content_types:
        enhanced_metadata['is_field_spec'] = True
        if detected_patterns.get('technical_field'):
            enhanced_metadata['technical_name'] = str(detected_patterns['technical_field'][0])
        if detected_patterns.get('format_spec'):
            enhanced_metadata['format_type'] = str(detected_patterns['format_spec'][0])
        if detected_patterns.get('length_spec'):
            enhanced_metadata['field_length'] = str(detected_patterns['length_spec'][0])
    else:
        enhanced_metadata['is_field_spec'] = False
    
    # Content quality indicators
    definition_keywords = ['Format:', 'Technical Name:', 'Length:', 'Position:', 'Definition:']
    enhanced_metadata['definition_completeness'] = sum(
        1 for keyword in definition_keywords if keyword in element.page_content
    )
    enhanced_metadata['is_complete_definition'] = enhanced_metadata['definition_completeness'] >= 3
    
    # Entity metadata (convert lists to comma-separated strings)
    enhanced_metadata['field_numbers'] = ','.join(key_entities['field_numbers']) if key_entities['field_numbers'] else ''
    enhanced_metadata['technical_names'] = ','.join(key_entities['technical_names']) if key_entities['technical_names'] else ''
    enhanced_metadata['key_concepts'] = ','.join(key_entities['concepts'][:5]) if key_entities['concepts'] else ''
    enhanced_metadata['abbreviations'] = ','.join(key_entities['abbreviations'][:5]) if key_entities['abbreviations'] else ''
    
    # Special indicators
    enhanced_metadata['has_values'] = bool(detected_patterns.get('value_mapping'))
    enhanced_metadata['has_cross_refs'] = bool(detected_patterns.get('appendix_ref') or detected_patterns.get('field_ref'))
    enhanced_metadata['is_appendix'] = 'appendix' in content_types
    enhanced_metadata['is_lookup_table'] = 'lookup_table' in content_types
    
    # Content difficulty/complexity score
    complexity_score = 0
    complexity_score += len(detected_patterns) * 2
    complexity_score += enhanced_metadata['definition_completeness'] * 3
    complexity_score += len(key_entities['technical_names']) * 2
    complexity_score += len(key_entities['abbreviations'])
    enhanced_metadata['complexity_score'] = min(20, complexity_score)  # Cap at 20
    
    # Ensure all values are compatible with ChromaDB (str, int, float, bool only)
    for key, value in enhanced_metadata.items():
        if isinstance(value, list):
            # Convert any remaining lists to comma-separated strings
            enhanced_metadata[key] = ','.join(str(v) for v in value)
        elif not isinstance(value, (str, int, float, bool, type(None))):
            # Convert any other types to strings
            enhanced_metadata[key] = str(value)
        elif value is None:
            # Convert None to empty string
            enhanced_metadata[key] = ''
    
    return enhanced_metadata

def load_single_document_enhanced(file_path):
    """Enhanced document loader with comprehensive pattern detection"""
    extension = os.path.splitext(file_path)[1].lower()
    processed_documents = []

    logger.info(f"Loading document: {file_path} ({extension})")

    # Select appropriate loader
    if extension == ".doc":
        loader = UnstructuredLoader(file_path, mode="elements", strategy="auto", chunking_strategy=None)
    elif extension in [".xlsx", ".xls"]:
        loader = UnstructuredExcelLoader(file_path, mode="elements")
    elif extension == ".txt":
        loader = TextLoader(file_path, encoding="utf-8")
    elif extension == ".rtf":
        # Try with UnstructuredLoader for RTF files
        loader = UnstructuredLoader(file_path, mode="elements", strategy="auto", chunking_strategy=None)
    else:
        logger.warning(f"Unsupported file type: {extension}. Skipping {file_path}")
        return []

    try:
        raw_elements = loader.load()
        logger.info(f"Loaded {len(raw_elements)} elements from {file_path}")
        
        for i, element in enumerate(raw_elements):
            # Preprocess content
            element.page_content = preprocess_text(element.page_content)
            if not element.page_content or len(element.page_content.strip()) < 10:
                continue
            
            # Detect patterns and classify content
            detected_patterns = detect_comprehensive_patterns(element.page_content)
            content_types = classify_content_type(element.page_content, detected_patterns)
            key_entities = extract_key_entities(element.page_content, detected_patterns)
            
            # Create enhanced metadata
            enhanced_metadata = create_enhanced_metadata(
                element, file_path, content_types, detected_patterns, key_entities
            )
            
            # Update element metadata
            element.metadata = enhanced_metadata
            
            # Log interesting findings
            if 'numbered_definition' in content_types:
                logger.info(f"  Found numbered definition: {enhanced_metadata.get('definition_number')}. {enhanced_metadata.get('definition_title', '')}")
            elif 'field_specification' in content_types:
                logger.info(f"  Found field spec: {enhanced_metadata.get('technical_name', 'Unknown')}")
            elif 'lookup_table' in content_types:
                logger.info(f"  Found lookup table with {len(detected_patterns.get('value_mapping', []))} values")
            
            processed_documents.append(element)
        
        logger.info(f"Processed {len(processed_documents)} elements from {file_path}")
        
    except Exception as e:
        logger.error(f"Error loading {file_path}: {e}")
        if extension == ".doc":
            logger.info("Ensure LibreOffice is installed for .doc processing")

    return processed_documents

def load_all_documents_enhanced(source_dir):
    """Load all documents from the source directory with enhanced processing"""
    all_documents = []
    
    if not os.path.exists(source_dir):
        logger.error(f"Documents directory '{source_dir}' not found.")
        return all_documents

    # Process each file in the directory
    for filename in os.listdir(source_dir):
        if filename.startswith('.'):
            logger.info(f"Skipping hidden file: {filename}")
            continue
        
        file_path = os.path.join(source_dir, filename)
        if os.path.isfile(file_path):
            documents = load_single_document_enhanced(file_path)
            all_documents.extend(documents)
    
    logger.info(f"Total documents loaded: {len(all_documents)}")
    return all_documents

def smart_chunking_strategy(text_splitter, documents):
    """Advanced chunking strategy that preserves different content types"""
    chunked_docs = []
    
    for doc in documents:
        content = doc.page_content
        metadata = doc.metadata
        content_types = metadata.get('content_types', [])
        
        # Strategy 1: Keep numbered definitions intact if possible
        if 'numbered_definition' in content_types and len(content) <= CHUNK_SIZE:
            # Single chunk for complete definitions
            doc.metadata['chunk_strategy'] = 'complete_definition'
            chunked_docs.append(doc)
            logger.debug(f"Preserved complete definition: {metadata.get('definition_number', 'Unknown')}")
            continue
        
        # Strategy 2: Keep field specifications together
        if 'field_specification' in content_types and len(content) <= CHUNK_SIZE * 1.2:
            doc.metadata['chunk_strategy'] = 'complete_field_spec'
            chunked_docs.append(doc)
            continue
        
        # Strategy 3: Smart splitting for lookup tables
        if 'lookup_table' in content_types:
            # Try to keep value mappings together
            value_blocks = re.split(r'\n\s*\n', content)
            if value_blocks:
                doc.metadata['chunk_strategy'] = 'table_preservation'
                for i, block in enumerate(value_blocks):
                    if len(block.strip()) > 20:  # Skip very short blocks
                        new_doc = doc.copy()
                        new_doc.page_content = block.strip()
                        new_doc.metadata['chunk_index'] = i
                        new_doc.metadata['total_chunks'] = len(value_blocks)
                        chunked_docs.append(new_doc)
                continue
        
        # Strategy 4: Preserve hierarchical content
        if 'hierarchy_definition' in content_types:
            # Split by hierarchy levels if too long
            hierarchy_splits = re.split(r'(\n[A-Z][A-Z\s]*:?\s*\n)', content)
            if len(hierarchy_splits) > 1 and len(content) > CHUNK_SIZE:
                doc.metadata['chunk_strategy'] = 'hierarchy_split'
                current_chunk = ""
                for split in hierarchy_splits:
                    if len(current_chunk + split) <= CHUNK_SIZE:
                        current_chunk += split
                    else:
                        if current_chunk.strip():
                            new_doc = doc.copy()
                            new_doc.page_content = current_chunk.strip()
                            chunked_docs.append(new_doc)
                        current_chunk = split
                
                # Add final chunk
                if current_chunk.strip():
                    new_doc = doc.copy()
                    new_doc.page_content = current_chunk.strip()
                    chunked_docs.append(new_doc)
                continue
        
        # Strategy 5: Default recursive splitting for large content
        if len(content) > CHUNK_SIZE:
            doc.metadata['chunk_strategy'] = 'recursive_split'
            chunks = text_splitter.split_documents([doc])
            for i, chunk in enumerate(chunks):
                chunk.metadata['chunk_index'] = i
                chunk.metadata['total_chunks'] = len(chunks)
                chunked_docs.append(chunk)
        else:
            # Keep as single chunk
            doc.metadata['chunk_strategy'] = 'single_chunk'
            chunked_docs.append(doc)
    
    return chunked_docs

def create_comprehensive_summary(final_metadatas, contents):
    """Create a comprehensive summary of indexed content"""
    logger.info("\n=== COMPREHENSIVE INDEXING SUMMARY ===")
    
    # Content type analysis
    content_type_counts = {}
    pattern_counts = {}
    chunk_strategy_counts = {}
    
    for metadata in final_metadatas:
        # Count content types (now comma-separated strings)
        content_types_str = metadata.get('content_types', '')
        if content_types_str:
            content_types = content_types_str.split(',')
            for content_type in content_types:
                content_type = content_type.strip()
                if content_type:
                    content_type_counts[content_type] = content_type_counts.get(content_type, 0) + 1
        
        # Count patterns (now comma-separated strings)
        patterns_str = metadata.get('detected_patterns', '')
        if patterns_str:
            patterns = patterns_str.split(',')
            for pattern in patterns:
                pattern = pattern.strip()
                if pattern:
                    pattern_counts[pattern] = pattern_counts.get(pattern, 0) + 1
        
        # Count chunk strategies
        strategy = metadata.get('chunk_strategy', 'unknown')
        chunk_strategy_counts[strategy] = chunk_strategy_counts.get(strategy, 0) + 1
    
    # Basic statistics
    total_chunks = len(final_metadatas)
    numbered_definitions = len([m for m in final_metadatas if m.get('is_numbered_definition') == True])
    complete_definitions = len([m for m in final_metadatas if m.get('is_complete_definition') == True])
    field_specs = len([m for m in final_metadatas if m.get('is_field_spec') == True])
    lookup_tables = len([m for m in final_metadatas if m.get('is_lookup_table') == True])
    
    # Content quality analysis
    high_quality_chunks = len([m for m in final_metadatas 
                              if isinstance(m.get('definition_completeness'), int) and m.get('definition_completeness') >= 4])
    complex_chunks = len([m for m in final_metadatas 
                         if isinstance(m.get('complexity_score'), int) and m.get('complexity_score') >= 10])
    
    # Print summary
    logger.info(f"Total chunks indexed: {total_chunks}")
    logger.info(f"Numbered definitions: {numbered_definitions}")
    logger.info(f"Complete definitions: {complete_definitions}")
    logger.info(f"Field specifications: {field_specs}")
    logger.info(f"Lookup tables: {lookup_tables}")
    logger.info(f"High-quality chunks: {high_quality_chunks}")
    logger.info(f"Complex chunks: {complex_chunks}")
    
    logger.info("\nContent Types Distribution:")
    for content_type, count in sorted(content_type_counts.items(), key=lambda x: x[1], reverse=True):
        logger.info(f"  {content_type}: {count}")
    
    logger.info("\nChunk Strategies Used:")
    for strategy, count in sorted(chunk_strategy_counts.items(), key=lambda x: x[1], reverse=True):
        logger.info(f"  {strategy}: {count}")
    
    logger.info("\nTop Detected Patterns:")
    for pattern, count in sorted(pattern_counts.items(), key=lambda x: x[1], reverse=True)[:10]:
        logger.info(f"  {pattern}: {count}")
    
    # Verify key definitions
    definition_numbers = []
    for m in final_metadatas:
        if m.get('definition_number'):
            definition_numbers.append(m.get('definition_number'))
    
    definition_numbers = sorted(set(definition_numbers), key=lambda x: int(x) if x and x.isdigit() else 999)
    
    logger.info(f"\nIndexed definition numbers: {definition_numbers[:20]}...")
    if len(definition_numbers) > 20:
        logger.info(f"... and {len(definition_numbers) - 20} more")
    
    logger.info("=====================================\n")

def main_enhanced_db_creation():
    """Main function to create the enhanced ChromaDB"""
    logger.info("Starting enhanced ChromaDB creation for medical data dictionary...")
    
    # Clean up existing database
    if os.path.exists(CHROMA_DB_DIR):
        logger.info(f"Removing existing ChromaDB at '{CHROMA_DB_DIR}'")
        shutil.rmtree(CHROMA_DB_DIR)
    
    os.makedirs(CHROMA_DB_DIR, exist_ok=True)
    logger.info(f"Created ChromaDB directory at '{CHROMA_DB_DIR}'")
    
    # Load documents with enhanced processing
    documents = load_all_documents_enhanced(DOCUMENTS_DIR)
    if not documents:
        logger.error("No documents loaded. Exiting.")
        return
    
    # Initialize text splitter with enhanced settings
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=CHUNK_SIZE,
        chunk_overlap=CHUNK_OVERLAP,
        length_function=len,
        is_separator_regex=False,
        separators=[
            "\n\n\n",  # Paragraph breaks
            "\n\n",    # Double newlines
            "\n",      # Single newlines
            ". ",      # Sentence endings
            ": ",      # Colon separators (common in definitions)
            "; ",      # Semicolon separators
            " ",       # Spaces
            ""         # Character level (last resort)
        ]
    )
    
    # Apply smart chunking strategy
    chunked_docs = smart_chunking_strategy(text_splitter, documents)
    logger.info(f"Created {len(chunked_docs)} chunks using smart chunking strategy")
    
    # Prepare data for ChromaDB
    if not chunked_docs:
        logger.error("No chunks created. Exiting.")
        return
    
    ids = [f"chunk_{i}" for i in range(len(chunked_docs))]
    contents = [doc.page_content for doc in chunked_docs]
    metadatas = []
    
    # Clean metadata to ensure ChromaDB compatibility
    for doc in chunked_docs:
        metadata = doc.metadata.copy()
        
        # Ensure all metadata values are ChromaDB-compatible (str, int, float, bool only)
        cleaned_metadata = {}
        for key, value in metadata.items():
            if isinstance(value, list):
                # Convert lists to comma-separated strings
                cleaned_metadata[key] = ','.join(str(v) for v in value)
            elif isinstance(value, dict):
                # Convert dicts to JSON strings
                import json
                cleaned_metadata[key] = json.dumps(value)
            elif value is None:
                # Convert None to empty string
                cleaned_metadata[key] = ''
            elif isinstance(value, (str, int, float, bool)):
                # Keep as-is if already compatible
                cleaned_metadata[key] = value
            else:
                # Convert everything else to string
                cleaned_metadata[key] = str(value)
        
        metadatas.append(cleaned_metadata)
    
    # Initialize ChromaDB
    logger.info("Initializing ChromaDB client...")
    client = chromadb.PersistentClient(path=CHROMA_DB_DIR)
    collection = client.get_or_create_collection(name=COLLECTION_NAME)
    
    # Generate embeddings and store
    logger.info("Generating embeddings...")
    try:
        embeddings_list = embeddings.embed_documents(contents)
        logger.info(f"Generated {len(embeddings_list)} embeddings")
        
        # Verify data consistency
        if not (len(ids) == len(embeddings_list) == len(contents) == len(metadatas)):
            logger.error("Data length mismatch!")
            logger.error(f"IDs: {len(ids)}, Embeddings: {len(embeddings_list)}, Contents: {len(contents)}, Metadata: {len(metadatas)}")
            return
        
        # Add to collection
        collection.add(
            ids=ids,
            embeddings=embeddings_list,
            documents=contents,
            metadatas=metadatas
        )
        
        logger.info("Successfully added all documents to ChromaDB")
        
        # Create comprehensive summary
        create_comprehensive_summary(metadatas, contents)
        
        # Final verification
        count = collection.count()
        logger.info(f"Final verification: Collection contains {count} items")
        
        # Test a sample query
        logger.info("Testing sample query...")
        test_results = collection.query(
            query_texts=["HCFA Admit Type Code"],
            n_results=3
        )
        logger.info(f"Sample query returned {len(test_results.get('documents', [[]])[0])} results")
        
        logger.info("Enhanced ChromaDB creation completed successfully!")
        
    except Exception as e:
        logger.error(f"Error during database creation: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    if not os.path.exists(DOCUMENTS_DIR) or not os.listdir(DOCUMENTS_DIR):
        logger.error(f"Documents directory '{DOCUMENTS_DIR}' is empty or does not exist.")
        logger.info("Please add your document files to this directory.")
    else:
        main_enhanced_db_creation()