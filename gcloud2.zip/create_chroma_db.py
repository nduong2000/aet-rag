# Updated rag_app/create_chroma_db.py
# Focus: Optimizing for a single .doc file with embedded XLS and preserving numbered definitions

import os
import shutil
import re
from langchain_community.document_loaders import (
    UnstructuredExcelLoader, 
    TextLoader,
)
from langchain_unstructured import UnstructuredLoader 
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_google_vertexai import VertexAIEmbeddings
import chromadb

# --- Configuration ---
DOCUMENTS_DIR = "./documents" 
CHROMA_DB_DIR = "./chroma_db_data"
COLLECTION_NAME = "rag_collection"
EMBEDDING_MODEL_NAME = "text-embedding-005"

# --- Chunking Strategy Parameters for a Single Complex Document ---
CHUNK_SIZE = 1200 
CHUNK_OVERLAP = 200

# --- Initialize Vertex AI Embeddings ---
try:
    embeddings = VertexAIEmbeddings(model_name=EMBEDDING_MODEL_NAME)
    print(f"Successfully initialized VertexAIEmbeddings with model: {EMBEDDING_MODEL_NAME}")
except Exception as e:
    print(f"Error initializing VertexAIEmbeddings: {e}")
    print("Please ensure you have authenticated with Google Cloud (e.g., `gcloud auth application-default login`)")
    print("and the Vertex AI API is enabled in your project.")
    print("If running locally, also ensure GOOGLE_CLOUD_PROJECT environment variable might be needed by the client library or for clarity.")
    exit()

def preprocess_text(text_content):
    """Basic text preprocessing."""
    if not text_content:
        return ""
    text_content = re.sub(r' +', ' ', text_content) 
    text_content = text_content.strip() 
    return text_content

def detect_definition_patterns(text_content):
    """
    Detect various patterns that indicate numbered definitions in the text
    """
    patterns = {
        'numbered_definition': r'^\s*(\d+)\.\s*([^:\n]+):\s*',
        'bulleted_definition': r'^\s*\*\s*([^:\n]+):\s*',
        'technical_name': r'Technical Name:\s*(\S+)',
        'format_field': r'Format:\s*(.+)',
        'length_field': r'Length:\s*(\d+)',
        'position_field': r'Position[s]?:\s*(\d+)',
    }
    
    found_patterns = {}
    for pattern_name, pattern in patterns.items():
        match = re.search(pattern, text_content, re.MULTILINE | re.IGNORECASE)
        if match:
            found_patterns[pattern_name] = match.groups()
    
    return found_patterns

def load_single_document_wrapper(file_path):
    """
    Wrapper for loading a single document, primarily focusing on .doc 
    and enhancing metadata for elements.
    """
    extension = os.path.splitext(file_path)[1].lower()
    processed_documents = []

    print(f"Attempting to load document: {file_path} with extension: {extension}")

    loader = None
    if extension == ".doc":
        print(f"Using UnstructuredLoader for .doc file: {file_path}")
        loader = UnstructuredLoader(file_path, mode="elements", strategy="auto", chunking_strategy=None) 
    elif extension in [".xlsx", ".xls"]: 
        print(f"Using UnstructuredExcelLoader for: {file_path}")
        loader = UnstructuredExcelLoader(file_path, mode="elements")
    elif extension == ".txt":
        loader = TextLoader(file_path, encoding="utf-8")
    else:
        print(f"Unsupported file type: {extension} for file {file_path}. Skipping.")
        return []

    try:
        if loader:
            raw_elements = loader.load() 
            
            for i, element in enumerate(raw_elements):
                element.page_content = preprocess_text(element.page_content)
                if not element.page_content: 
                    continue

                current_metadata = {}
                if hasattr(element, 'metadata') and isinstance(element.metadata, dict):
                    current_metadata = element.metadata.copy()

                current_metadata["source_filename"] = os.path.basename(file_path)
                page_num = current_metadata.get('page_number', i + 1) 
                current_metadata["page_number"] = page_num
                element_type = current_metadata.get('category', 'Unknown') 
                current_metadata["element_type"] = element_type
                
                if len(element.page_content) < 100: 
                    current_metadata["element_preview"] = element.page_content

                # Enhanced pattern detection
                detected_patterns = detect_definition_patterns(element.page_content)
                
                # Enhanced detection for numbered definitions
                if element_type == "Table":
                    print(f"  Found Table element on page {page_num} in {file_path}")
                elif element_type == "ListItem":
                    if re.match(r"^\s*\d+\.\s*[\w\s\(\)\–\-\:]+", element.page_content):
                        print(f"  Found ListItem element that looks like a definition start: {element.page_content[:50]}...")
                        current_metadata["is_definition_item_start"] = True
                        # Extract the definition number for better identification
                        number_match = re.match(r"^\s*(\d+)\.", element.page_content)
                        if number_match:
                            current_metadata["definition_number"] = number_match.group(1)

                # Check if this element contains a numbered definition pattern
                numbered_def_pattern = r'^\s*(\d+)\.\s*([^\n:]+):\s*'
                numbered_match = re.match(numbered_def_pattern, element.page_content)
                if numbered_match:
                    current_metadata["contains_numbered_definition"] = True
                    current_metadata["definition_number"] = numbered_match.group(1)
                    current_metadata["definition_title"] = numbered_match.group(2).strip()
                    current_metadata["definition_type"] = "numbered"
                    print(f"  Found numbered definition: {numbered_match.group(1)}. {numbered_match.group(2)}")
                
                # Enhanced metadata for definition structures
                if detected_patterns:
                    current_metadata["detected_patterns"] = list(detected_patterns.keys())
                    
                    # Check for complete definition structure
                    if ('numbered_definition' in detected_patterns or 
                        current_metadata.get("contains_numbered_definition")) and \
                       ('technical_name' in detected_patterns or 
                        'format_field' in detected_patterns):
                        current_metadata["is_complete_definition_block"] = True
                        current_metadata["definition_completeness_score"] = len(detected_patterns)
                
                # Additional metadata for better retrieval
                if re.search(r'\b(Format|Technical Name|Length|Position)\s*:', element.page_content, re.IGNORECASE):
                    current_metadata["contains_definition_fields"] = True
                
                # Count definition-like structures
                definition_keywords = ['Format:', 'Technical Name:', 'Length:', 'Position:', 'Definition:']
                field_count = sum(1 for keyword in definition_keywords if keyword in element.page_content)
                if field_count > 0:
                    current_metadata["definition_field_count"] = field_count

                for key, value in list(current_metadata.items()):
                    if not isinstance(value, (str, int, float, bool, type(None))):
                        current_metadata[key] = str(value)
                
                element.metadata = current_metadata
                processed_documents.append(element)
            
            print(f"Successfully loaded and processed {len(processed_documents)} elements from {file_path}")
    except Exception as e:
        print(f"Error loading document {file_path} with loader {type(loader).__name__}: {e}")
        if isinstance(loader, UnstructuredLoader):
            print("  Ensure 'libreoffice' is installed in your environment/Dockerfile for .doc processing.")
    
    return processed_documents

def load_all_documents_from_sources(source_dir):
    all_document_elements = []
    if not os.path.exists(source_dir):
        print(f"Error: Documents directory '{source_dir}' not found.")
        return all_document_elements

    for filename in os.listdir(source_dir):
        file_path = os.path.join(source_dir, filename)
        if os.path.isfile(file_path):
            if filename.startswith('.'): 
                print(f"Skipping hidden file: {filename}")
                continue
            
            elements_from_file = load_single_document_wrapper(file_path)
            if elements_from_file:
                all_document_elements.extend(elements_from_file)
            else:
                print(f"No content loaded or processed from {filename}.")
    return all_document_elements

def smart_split_for_definitions(text_splitter, documents_elements):
    """
    Enhanced splitting that tries to preserve numbered definition blocks
    """
    split_chunks = []
    
    for doc in documents_elements:
        content = doc.page_content
        
        # Enhanced pattern for detecting complete definition blocks
        numbered_def_pattern = r'(\d+\.\s+[^\n:]+:.*?)(?=\n\d+\.\s+|\n[A-Z][^\n]*:|\Z)'
        numbered_defs = re.findall(numbered_def_pattern, content, re.DOTALL)
        
        if numbered_defs:
            print(f"Found {len(numbered_defs)} numbered definitions in document")
            
            # Process each numbered definition as a separate chunk if it's not too large
            for def_text in numbered_defs:
                if len(def_text) <= CHUNK_SIZE:
                    # Keep the definition as a single chunk
                    new_doc = doc.copy()
                    new_doc.page_content = def_text.strip()
                    
                    # Enhance metadata for numbered definition chunks
                    numbered_match = re.match(r'(\d+)\.\s*([^\n:]+):', def_text)
                    if numbered_match:
                        new_doc.metadata["is_complete_definition"] = True
                        new_doc.metadata["definition_number"] = numbered_match.group(1)
                        new_doc.metadata["definition_title"] = numbered_match.group(2).strip()
                        new_doc.metadata["chunk_type"] = "complete_definition"
                        
                        # Count definition fields in this chunk
                        field_patterns = [
                            'Format:',
                            'Technical Name:',
                            'Length:',
                            'Position[s]?:',
                            'Definition:'
                        ]
                        field_count = 0
                        for pattern in field_patterns:
                            if re.search(pattern, def_text, re.IGNORECASE):
                                field_count += 1
                        new_doc.metadata["definition_field_count"] = field_count
                        
                        # Mark as high-quality definition if it has multiple fields
                        if field_count >= 3:
                            new_doc.metadata["is_high_quality_definition"] = True
                    
                    split_chunks.append(new_doc)
                    print(f"Preserved as single chunk: {def_text[:50]}...")
                else:
                    # Definition is too large, split it but try to preserve structure
                    # Create a temporary document for this definition
                    temp_doc = doc.copy()
                    temp_doc.page_content = def_text
                    def_chunks = text_splitter.split_documents([temp_doc])
                    
                    # Mark each chunk as part of a numbered definition
                    for chunk in def_chunks:
                        numbered_match = re.match(r'(\d+)\.\s*([^\n:]+):', def_text)
                        if numbered_match:
                            chunk.metadata["is_part_of_definition"] = True
                            chunk.metadata["definition_number"] = numbered_match.group(1)
                            chunk.metadata["definition_title"] = numbered_match.group(2).strip()
                            chunk.metadata["chunk_type"] = "partial_definition"
                    
                    split_chunks.extend(def_chunks)
        else:
            # No numbered definitions found, use regular splitting
            regular_chunks = text_splitter.split_documents([doc])
            
            # Add metadata to indicate these are regular chunks
            for chunk in regular_chunks:
                chunk.metadata["chunk_type"] = "regular"
            
            split_chunks.extend(regular_chunks)
    
    return split_chunks

def create_summary_report(final_metadatas):
    """
    Create a summary report of the indexed content
    """
    print("\n=== INDEXING SUMMARY REPORT ===")
    
    # Count different types of chunks
    complete_definitions = 0
    partial_definitions = 0
    high_quality_definitions = 0
    numbered_definitions = set()
    regular_chunks = 0
    
    for metadata in final_metadatas:
        chunk_type = metadata.get("chunk_type", "unknown")
        
        if chunk_type == "complete_definition":
            complete_definitions += 1
            if metadata.get("is_high_quality_definition"):
                high_quality_definitions += 1
        elif chunk_type == "partial_definition":
            partial_definitions += 1
        elif chunk_type == "regular":
            regular_chunks += 1
        
        # Collect numbered definitions
        if metadata.get("definition_number"):
            numbered_definitions.add(metadata.get("definition_number"))
    
    print(f"Total chunks indexed: {len(final_metadatas)}")
    print(f"Complete definitions: {complete_definitions}")
    print(f"Partial definitions: {partial_definitions}")
    print(f"High-quality definitions: {high_quality_definitions}")
    print(f"Regular chunks: {regular_chunks}")
    print(f"Unique numbered definitions found: {len(numbered_definitions)}")
    print(f"Definition numbers: {sorted(numbered_definitions, key=int)}")
    print("===============================\n")

def main_db_creation():
    print("Starting ChromaDB creation process for RAG...")

    if os.path.exists(CHROMA_DB_DIR):
        print(f"Found existing ChromaDB directory at '{CHROMA_DB_DIR}'. Removing it.")
        shutil.rmtree(CHROMA_DB_DIR)
    os.makedirs(CHROMA_DB_DIR, exist_ok=True)
    print(f"Created ChromaDB directory at '{CHROMA_DB_DIR}'.")

    print(f"Loading document(s) from '{DOCUMENTS_DIR}'...")
    documents_elements = load_all_documents_from_sources(DOCUMENTS_DIR)
    if not documents_elements:
        print("No document elements loaded. Exiting ChromaDB creation.")
        return

    print(f"Total document elements loaded: {len(documents_elements)}")

    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=CHUNK_SIZE,
        chunk_overlap=CHUNK_OVERLAP,
        length_function=len,
        is_separator_regex=False,
        separators=["\n\n\n", "\n\n", "\n", ". ", " ", ""] 
    )
    
    # Use enhanced splitting for numbered definitions
    split_chunks = smart_split_for_definitions(text_splitter, documents_elements)
    print(f"Document elements split into {len(split_chunks)} text chunks using enhanced strategy.")

    if not split_chunks:
        print("No text chunks to process after splitting. Exiting.")
        return

    ids = [f"chunk_{i}" for i in range(len(split_chunks))]
    contents = [chunk.page_content for chunk in split_chunks]
    
    final_metadatas = []
    for i, chunk in enumerate(split_chunks):
        metadata_to_add = {}
        if hasattr(chunk, 'metadata') and isinstance(chunk.metadata, dict):
            for key, value in chunk.metadata.items():
                if isinstance(value, (str, int, float, bool, type(None))):
                    metadata_to_add[key] = value
                else: 
                    metadata_to_add[key] = str(value)
        else: 
            metadata_to_add = {"source_filename": "Unknown", "page_number": "N/A", "element_type": "Unknown"}
        final_metadatas.append(metadata_to_add)

    print(f"Initializing ChromaDB client with path: '{CHROMA_DB_DIR}'")
    client = chromadb.PersistentClient(path=CHROMA_DB_DIR)
    collection = client.get_or_create_collection(name=COLLECTION_NAME)
    print(f"Collection '{COLLECTION_NAME}' ready.")

    print("Generating embeddings for text chunks...")
    try:
        if not contents or not all(isinstance(c, str) for c in contents):
            print("Error: Contents for embedding are empty or contain non-string elements.")
            return

        chunk_embeddings = embeddings.embed_documents(contents)
        print(f"Successfully generated {len(chunk_embeddings)} embeddings.")

        if not (len(ids) == len(chunk_embeddings) == len(contents) == len(final_metadatas)):
            print("Error: Mismatch in lengths of lists for ChromaDB.")
            print(f"IDs: {len(ids)}, Embeddings: {len(chunk_embeddings)}, Contents: {len(contents)}, Metadatas: {len(final_metadatas)}")
            return

        collection.add(ids=ids, embeddings=chunk_embeddings, documents=contents, metadatas=final_metadatas)
        print("Successfully added documents and embeddings to ChromaDB.")

        # Create a summary report
        create_summary_report(final_metadatas)

        # Verify numbered definitions were properly indexed
        print("Verifying numbered definition indexing...")
        definition_count = 0
        examples = []
        for i, metadata in enumerate(final_metadatas):
            if metadata.get("is_complete_definition") or metadata.get("contains_numbered_definition"):
                definition_count += 1
                examples.append({
                    'number': metadata.get('definition_number'),
                    'title': metadata.get('definition_title', 'Unknown'),
                    'type': metadata.get('chunk_type', 'unknown'),
                    'content_preview': contents[i][:100] + "..." if len(contents[i]) > 100 else contents[i]
                })
        
        print(f"\nTotal numbered definitions indexed: {definition_count}")
        print("\nExamples of indexed definitions:")
        for example in examples[:5]:  # Show first 5 examples
            print(f"  {example['number']}. {example['title']} ({example['type']})")
            print(f"    Preview: {example['content_preview']}\n")

    except Exception as e:
        print(f"Error during embedding generation or adding to ChromaDB: {e}")
        import traceback
        traceback.print_exc()
        return

    count = collection.count()
    print(f"Verification: Collection '{COLLECTION_NAME}' now contains {count} items.")
    if count > 0:
        print("ChromaDB creation process completed successfully.")
    else:
        print("ChromaDB creation might have failed.")

if __name__ == "__main__":
    if not os.path.exists(DOCUMENTS_DIR) or (len(os.listdir(DOCUMENTS_DIR)) == 0):
        print(f"The '{DOCUMENTS_DIR}' directory is empty or does not exist.")
        print("Please add your single .doc file (or other supported files) to this directory.")
    else:
        main_db_creation()