# Conceptual rag_app/main.py (Illustrative - adapt to your Flask setup)
# Focus: Optimizing for a single .doc file with embedded XLS and structured definitions

import os
from dotenv import load_dotenv 
from flask import Flask, request, jsonify, render_template 
from langchain_google_vertexai import VertexAIEmbeddings, ChatVertexAI
import chromadb
import sys 
import re # For extracting item title from query

load_dotenv() 

# --- Configuration ---
CHROMA_DB_DIR = "./chroma_db_data"
COLLECTION_NAME = "rag_collection"
EMBEDDING_MODEL_NAME = "text-embedding-005"
CHAT_MODEL_NAME = "gemini-2.5-pro-preview-05-06" # Using the flash model
GCP_PROJECT_ID = os.getenv("GOOGLE_CLOUD_PROJECT")

LLM_TEMPERATURE = 0.05 # Keep low for precise reproduction
NUM_RETRIEVED_DOCS = 15 # Increased number of docs to retrieve for better definition coverage
RETRIEVAL_DISTANCE_THRESHOLD = 0.85 # Adjusted for better precision

ENABLE_QUERY_REWRITING = True 
ENABLE_HYDE = False 

app = Flask(__name__, template_folder='templates')

embeddings_service = None
chat_model = None
chroma_client = None
collection = None

def init_clients_rag(): 
    global embeddings_service, chat_model, chroma_client, collection
    if not GCP_PROJECT_ID:
        raise ValueError("GOOGLE_CLOUD_PROJECT environment variable is essential and not set.")
    if not embeddings_service:
        embeddings_service = VertexAIEmbeddings(model_name=EMBEDDING_MODEL_NAME, project=GCP_PROJECT_ID)
    if not chat_model:
        chat_model = ChatVertexAI(model_name=CHAT_MODEL_NAME, project=GCP_PROJECT_ID, temperature=LLM_TEMPERATURE) 
        print(f"Initialized ChatVertexAI with model: {CHAT_MODEL_NAME}") 
    if not chroma_client:
        if not os.path.exists(CHROMA_DB_DIR):
            raise FileNotFoundError(f"ChromaDB directory '{CHROMA_DB_DIR}' missing. Run create_chroma_db.py first.")
        chroma_client = chromadb.PersistentClient(path=CHROMA_DB_DIR)
    if not collection:
        try:
            collection = chroma_client.get_collection(name=COLLECTION_NAME)
            print(f"Loaded Chroma collection '{COLLECTION_NAME}' ({collection.count()} items).")
        except Exception as e:
            print(f"Error: Collection '{COLLECTION_NAME}' not found in ChromaDB at '{CHROMA_DB_DIR}'. {e}")
            raise
try:
    init_clients_rag()
except Exception as e:
    print(f"FATAL: Error during RAG client initialization: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)


def get_enhanced_query_embedding_rag(user_query: str):
    effective_query_for_embedding = user_query
    
    # Extract core term (enhanced patterns for numbered definitions)
    match_what_is = re.search(r"what is (.*)", user_query, re.IGNORECASE)
    match_define = re.search(r"define (.*)", user_query, re.IGNORECASE)
    match_explain = re.search(r"explain (.*)", user_query, re.IGNORECASE)
    
    # Enhanced pattern for numbered definitions like "141. HCFA Admit Type Code"
    match_numbered_def = re.search(r"(\d+\.?\s*)?([\w\s\(\)\–\-\'\"]+?)(?:\s*:|\?)?$", user_query.strip(), re.IGNORECASE)
    
    # Pattern for direct term queries (no "what is" prefix)
    match_direct_term = re.match(r"^(?:\d+\.\s*)?([\w\s\(\)\–\-\'\"]+?)(?:\s*:|\?)?$", user_query.strip())
    
    # Check for NAP or similar terms specifically
    has_nap = re.search(r'\bNAP\b|\bNational Advantage Program\b', user_query, re.IGNORECASE)
    
    core_term = user_query  # Default to full query
    term_number = None  # Store the number if found
    
    if match_what_is:
        potential_term = match_what_is.group(1).strip().rstrip(':').rstrip('?').strip()
        # Check if the extracted term has a number prefix
        numbered_match = re.match(r"^(\d+\.?\s*)?(.*)", potential_term)
        if numbered_match:
            term_number = numbered_match.group(1)
            core_term = numbered_match.group(2).strip()
        else:
            core_term = potential_term
        print(f"Extracted core term via 'what is': '{core_term}' (number: {term_number})")
    elif match_define:
        potential_term = match_define.group(1).strip().rstrip(':').rstrip('?').strip()
        numbered_match = re.match(r"^(\d+\.?\s*)?(.*)", potential_term)
        if numbered_match:
            term_number = numbered_match.group(1)
            core_term = numbered_match.group(2).strip()
        else:
            core_term = potential_term
        print(f"Extracted core term via 'define': '{core_term}' (number: {term_number})")
    elif match_explain:
        potential_term = match_explain.group(1).strip().rstrip(':').rstrip('?').strip()
        numbered_match = re.match(r"^(\d+\.?\s*)?(.*)", potential_term)
        if numbered_match:
            term_number = numbered_match.group(1)
            core_term = numbered_match.group(2).strip()
        else:
            core_term = potential_term
        print(f"Extracted core term via 'explain': '{core_term}' (number: {term_number})")
    elif match_numbered_def:
        term_number = match_numbered_def.group(1)
        core_term = match_numbered_def.group(2).strip()
        print(f"Extracted core term via numbered definition: '{core_term}' (number: {term_number})")
    elif match_direct_term:
        core_term = match_direct_term.group(1).strip()
        print(f"Extracted core term via direct match: '{core_term}'")
    else:
        print(f"Could not extract specific term, using full query for rewrite/embedding basis: '{core_term}'")

    # Clean up the term (remove quotes, etc.)
    core_term = core_term.strip('\'\"')
    print(f"Identified core term for embedding: '{core_term}' (with number: {term_number})")

    if ENABLE_QUERY_REWRITING and not ENABLE_HYDE:
        try:
            # Enhanced rewrite prompt that preserves important numerical identifiers
            if term_number:
                rewrite_prompt_template = (
                    "Optimize the following numbered definition query for semantic search in a data dictionary. "
                    "The query refers to a numbered definition entry. Preserve key identifying information. Examples:\n"
                    "'141. HCFA Admit Type Code:' -> 'HCFA Admit Type Code 141'\n"
                    "'what is 101. COB Paid Amount:' -> 'COB Paid Amount 101'\n"
                    "'AHF_BFD_AMT' -> 'AHF_BFD_AMT'\n"
                    "Return an optimized search term that includes both the term name and its number if applicable.\n"
                    "Original Query: \"{query}\"\n"
                    "Core Term: \"{term}\"\n"
                    "Number: \"{number}\"\n"
                    "Optimized Search Term:"
                )
                rewrite_prompt = rewrite_prompt_template.format(
                    query=user_query, 
                    term=core_term, 
                    number=term_number.strip() if term_number else ""
                )
            else:
                rewrite_prompt_template = (
                    "Optimize the following term/query for semantic search in a data dictionary. "
                    "Focus on the essential name of the field or concept. Examples:\n"
                    "'101. COB Paid Amount:' -> 'COB Paid Amount'\n"
                    "'AHF_BFD_AMT' -> 'AHF_BFD_AMT'\n"
                    "'Aetna Health Fund – Before Fund Deductible' -> 'Aetna Health Fund – Before Fund Deductible'\n"
                    "Return only the optimized search term.\n"
                    "Original Term/Query: \"{term}\"\n"
                    "Optimized Search Term:"
                )
                rewrite_prompt = rewrite_prompt_template.format(term=core_term)
            
            if chat_model:
                rephrased_query_response = chat_model.invoke(rewrite_prompt)
                rephrased_query = rephrased_query_response.content.strip().strip('"')
                
                # Use rephrased query only if it's non-empty and potentially different
                if rephrased_query and rephrased_query.lower() != core_term.lower(): 
                    print(f"Original query: '{user_query}', Core term: '{core_term}', Rephrased for embedding: '{rephrased_query}'")
                    effective_query_for_embedding = rephrased_query
                else:
                    # If no significant rephrasing, combine term with number for better matching
                    if term_number:
                        effective_query_for_embedding = f"{core_term} {term_number.strip()}"
                    else:
                        effective_query_for_embedding = core_term 
                    print(f"Query rewriting did not produce a significantly different term, using: '{effective_query_for_embedding}'")
            else: 
                effective_query_for_embedding = f"{core_term} {term_number.strip()}" if term_number else core_term
        except Exception as e:
            print(f"Error during query rewriting, falling back to core term '{core_term}': {e}")
            effective_query_for_embedding = f"{core_term} {term_number.strip()}" if term_number else core_term
    else: 
        effective_query_for_embedding = f"{core_term} {term_number.strip()}" if term_number else core_term
        
    if not embeddings_service: raise RuntimeError("Embeddings service not initialized.")
    print(f"Final query for embedding: '{effective_query_for_embedding}'")
    return embeddings_service.embed_query(effective_query_for_embedding)


def get_numbered_definition_context(query, collection, embeddings_service, user_query_term):
    """
    Special retrieval strategy for numbered definitions like "141. HCFA Admit Type Code"
    """
    # Extract number from the query if present
    number_match = re.search(r'(\d+)\.?\s*', query)
    if number_match:
        number = number_match.group(1)
        
        # Create specific search queries for numbered definitions
        search_queries = [
            f"{number}. {user_query_term}",  # "141. HCFA Admit Type Code"
            f"{number}. {user_query_term.upper()}",  # Try uppercase version
            f"{user_query_term} {number}",  # "HCFA Admit Type Code 141"
            user_query_term,  # Just the term itself
        ]
        
        all_results = []
        seen_docs = set()
        
        for search_query in search_queries:
            try:
                print(f"Searching with numbered definition strategy: '{search_query}'")
                query_embedding = embeddings_service.embed_query(search_query)
                
                results = collection.query(
                    query_embeddings=[query_embedding],
                    n_results=5,  # Get fewer but more focused results for each query
                    include=["documents", "metadatas", "distances"]
                )
                
                if results and results.get('documents'):
                    for i, doc in enumerate(results.get('documents', [[]])[0]):
                        # Avoid duplicates
                        if doc not in seen_docs:
                            seen_docs.add(doc)
                            all_results.append({
                                'document': doc,
                                'metadata': results.get('metadatas', [[]])[0][i] if i < len(results.get('metadatas', [[]])[0]) else {},
                                'distance': results.get('distances', [[]])[0][i] if i < len(results.get('distances', [[]])[0]) else 1.0
                            })
                            
                            # Check if this document contains the exact numbered definition
                            if re.search(rf"{number}\.\s*{re.escape(user_query_term)}", doc, re.IGNORECASE):
                                print(f"Found exact match for {number}. {user_query_term}")
                                # Move this to the front of the results
                                all_results[-1]['is_exact_match'] = True
                        
            except Exception as e:
                print(f"Error in numbered definition search with query '{search_query}': {e}")
        
        # Sort results: exact matches first, then by distance
        all_results.sort(key=lambda x: (not x.get('is_exact_match', False), x['distance']))
        return all_results[:10]  # Return top 10 results
    
    return []


def post_process_and_rank_results(retrieved_docs_content, retrieved_metadatas, retrieved_distances, user_query, user_query_term):
    """
    Post-process and rank results based on exact pattern matches and relevance scores
    """
    combined_results = []
    
    # Extract number from query if present
    number_match = re.search(r'(\d+)\.?\s*', user_query)
    query_number = number_match.group(1) if number_match else None
    
    for i, content in enumerate(retrieved_docs_content):
        metadata = retrieved_metadatas[i] if i < len(retrieved_metadatas) else {}
        distance = retrieved_distances[i] if i < len(retrieved_distances) else 1.0
        
        # Calculate relevance score
        relevance_score = 0.0
        
        # 1. Exact numbered definition match (highest priority)
        if query_number:
            exact_pattern = rf"^{query_number}\.\s*{re.escape(user_query_term)}:\s*"
            if re.search(exact_pattern, content, re.IGNORECASE):
                relevance_score += 100.0
                print(f"  *** EXACT NUMBERED DEFINITION MATCH *** {query_number}. {user_query_term}")
        
        # 2. Numbered definition with different number but same term
        numbered_def_pattern = rf"^(\d+)\.\s*{re.escape(user_query_term)}:\s*"
        numbered_match = re.search(numbered_def_pattern, content, re.IGNORECASE)
        if numbered_match:
            relevance_score += 80.0
            found_number = numbered_match.group(1)
            print(f"  Found numbered definition: {found_number}. {user_query_term}")
        
        # 3. Term appears at the beginning (high priority)
        if content.lower().startswith(user_query_term.lower().strip()):
            relevance_score += 60.0
        
        # 4. Term appears in a heading or title format (medium-high priority)
        heading_patterns = [
            rf"{re.escape(user_query_term)}:",
            rf"^{re.escape(user_query_term)}\s*$",
            rf"\*\*{re.escape(user_query_term)}\*\*",
        ]
        for pattern in heading_patterns:
            if re.search(pattern, content, re.IGNORECASE):
                relevance_score += 40.0
                break
        
        # 5. Exact phrase match anywhere in text
        if re.search(rf"\b{re.escape(user_query_term)}\b", content, re.IGNORECASE):
            relevance_score += 30.0
        
        # 6. Bonus for complete definition blocks (from metadata)
        if metadata.get("is_complete_definition") or metadata.get("contains_numbered_definition"):
            relevance_score += 20.0
        
        # 7. Metadata-based scoring
        if metadata.get("definition_number") == query_number:
            relevance_score += 15.0
        
        # 8. Distance-based scoring (lower distance = higher score)
        distance_score = max(0, 10.0 * (1.0 - distance))
        relevance_score += distance_score
        
        # 9. Penalty for very short content that might not be complete
        if len(content.strip()) < 50:
            relevance_score -= 5.0
        
        combined_results.append({
            'content': content,
            'metadata': metadata,
            'distance': distance,
            'relevance_score': relevance_score,
            'index': i
        })
    
    # Sort by relevance score (descending) and then by distance (ascending)
    combined_results.sort(key=lambda x: (-x['relevance_score'], x['distance']))
    
    # Print ranking information
    print("\n--- Post-Processing Results Ranking ---")
    for i, result in enumerate(combined_results[:5]):  # Show top 5
        print(f"{i+1}. Score: {result['relevance_score']:.2f}, Distance: {result['distance']:.4f}")
        print(f"   Content: {result['content'][:100]}...")
        print(f"   Metadata: {result['metadata']}")
    
    # Extract reordered lists
    reordered_docs = [r['content'] for r in combined_results]
    reordered_metadatas = [r['metadata'] for r in combined_results]
    reordered_distances = [r['distance'] for r in combined_results]
    
    return reordered_docs, reordered_metadatas, reordered_distances


@app.route('/')
def index_route(): 
    return render_template('chat.html')

@app.route('/chat_rag', methods=['POST']) 
def chat_handler_rag():
    if not all([embeddings_service, chat_model, collection]):
         return jsonify({"error": "RAG components not initialized."}), 500

    data = request.get_json()
    user_query = data.get('query')
    if not user_query: return jsonify({"error": "Query not provided"}), 400

    # --- Try to identify the specific term the user is asking about ---
    user_query_term = user_query # Default
    match_what_is = re.search(r"what is (.*)", user_query, re.IGNORECASE)
    match_define = re.search(r"define (.*)", user_query, re.IGNORECASE)
    match_explain = re.search(r"explain (.*)", user_query, re.IGNORECASE)
    match_direct_term = re.match(r"^(?:\d+\.\s*)?([\w\s\(\)\–\-\'\"]+?)(?:\s*:|\?)?$", user_query.strip())
    
    # Check for NAP or similar terms specifically
    has_nap = re.search(r'\bNAP\b|\bNational Advantage Program\b', user_query, re.IGNORECASE)
    
    if match_what_is:
        potential_term = match_what_is.group(1).strip().rstrip(':').rstrip('?').strip()
        term_only_match = re.match(r"^(?:\d+\.\s*)?([\w\s\(\)\–\-\'\"]+?)$", potential_term)
        if term_only_match: user_query_term = term_only_match.group(1).strip()
        else: user_query_term = potential_term
    elif match_define:
        potential_term = match_define.group(1).strip().rstrip(':').rstrip('?').strip()
        user_query_term = potential_term
    elif match_explain:
        potential_term = match_explain.group(1).strip().rstrip(':').rstrip('?').strip()
        user_query_term = potential_term
    elif match_direct_term:
        user_query_term = match_direct_term.group(1).strip()
    
    # Clean up the term (remove quotes, etc.)
    user_query_term = user_query_term.strip('\'\"')
    print(f"Identified user query term for matching context: '{user_query_term}'")

    try:
        print(f"Original user query: {user_query}")
        query_embedding = get_enhanced_query_embedding_rag(user_query)

        print(f"Querying ChromaDB for {NUM_RETRIEVED_DOCS} results...")
        results = collection.query(
            query_embeddings=[query_embedding],
            n_results=NUM_RETRIEVED_DOCS,
            include=["documents", "metadatas", "distances"] 
        )

        retrieved_docs_content = results.get('documents', [[]])[0]
        retrieved_metadatas = results.get('metadatas', [[]])[0]
        retrieved_distances = results.get('distances', [[]])[0] 

        # Special handling for numbered definitions
        numbered_def_match = re.search(r'(\d+)\.?\s*(.+)', user_query, re.IGNORECASE)
        if numbered_def_match:
            print("Detected numbered definition query, applying special retrieval strategy...")
            numbered_results = get_numbered_definition_context(user_query, collection, embeddings_service, user_query_term)
            
            # Merge numbered definition results with the original results
            for result in numbered_results:
                if result['document'] not in retrieved_docs_content:
                    retrieved_docs_content.append(result['document'])
                    retrieved_metadatas.append(result['metadata'])
                    retrieved_distances.append(result['distance'])
                    print(f"Added numbered definition result: {result['document'][:100]}...")

        # Special case for NAP/National Advantage Program queries
        if has_nap:
            print("NAP-related query detected, performing targeted retrieval...")
            # Generate the embedding ourselves instead of letting ChromaDB do it
            nap_query_text = "National Advantage Program NAP fees"
            try:
                nap_embedding = embeddings_service.embed_query(nap_query_text)
                nap_results = collection.query(
                    query_embeddings=[nap_embedding],  # Use our own embedding with correct dimensions
                    n_results=5,
                    include=["documents", "metadatas", "distances"]
                )
                
                # Add the NAP-specific results to the existing results if they're not already there
                if nap_results and nap_results.get('documents'):
                    for i, doc in enumerate(nap_results.get('documents', [[]])[0]):
                        if doc not in retrieved_docs_content:
                            retrieved_docs_content.append(doc)
                            retrieved_metadatas.append(nap_results.get('metadatas', [[]])[0][i])
                            retrieved_distances.append(nap_results.get('distances', [[]])[0][i])
                            print(f"Added NAP-specific document: {doc[:100]}...")
            except Exception as e:
                print(f"Error during NAP-specific retrieval, continuing with standard results: {e}")
                import traceback
                traceback.print_exc()
        
        # Apply post-processing and ranking
        print("\n--- Applying Post-Processing and Ranking ---")
        retrieved_docs_content, retrieved_metadatas, retrieved_distances = post_process_and_rank_results(
            retrieved_docs_content, retrieved_metadatas, retrieved_distances, user_query, user_query_term
        )
        
        context_str = "No relevant information was found in the document for your query."
        final_answer = "I do not have enough information in the provided document excerpts to answer that question."
        
        if retrieved_docs_content:
            context_parts = []
            print("\nRetrieved Chunks for Context (after ranking):")
            best_match_found = False
            for i, content in enumerate(retrieved_docs_content):
                meta = retrieved_metadatas[i] if i < len(retrieved_metadatas) else {}
                dist = retrieved_distances[i] if i < len(retrieved_distances) else 1.0
                source = meta.get('source_filename', 'Unknown source')
                page = meta.get('page_number', 'N/A')
                element_type = meta.get('element_type', 'text') 
                
                # --- Filter by distance threshold ---
                if dist > RETRIEVAL_DISTANCE_THRESHOLD:
                     print(f"  Skipping chunk (distance {dist:.4f} > threshold {RETRIEVAL_DISTANCE_THRESHOLD}): {content[:100]}...")
                     continue

                # --- Heuristic to find the chunk starting with the exact term ---
                # Use the extracted user_query_term for a more precise match
                # This regex looks for optional number, dot, space, then the term, then colon or newline
                if re.search(rf"\b{re.escape(user_query_term)}\b", content, re.IGNORECASE):
                    print(f"  ** Found content with '{user_query_term}' ** (Distance: {dist:.4f})")
                    # If we find a very good match (low distance) that starts correctly, we might prioritize it.
                    # For now, we'll just log it and include it in context_parts.
                    best_match_found = True # Flag that we found at least one promising block

                print(f"  - Source: {source}, Page: {page}, Type: {element_type}, Distance: {dist:.4f}")
                print(f"    Content (snippet): {content[:150]}...")
                context_parts.append(f"[Source: {source}, Page: {page}, Type: {element_type}]\n{content}")
            
            if not context_parts: 
                 context_str = "No relevant information found matching the similarity threshold."
                 final_answer = "I could not find relevant information matching the required similarity for that term."
            else:
                context_str = "\n\n---\n\n".join(context_parts)
                print(f"\nFinal Context String (snippet): {context_str[:700]}...")

                # Enhanced prompt template for numbered definitions
                prompt_template = """You are an AI assistant that extracts and explains information from a data dictionary document based on the provided context excerpts.

The user asked about: "{original_question}"
The specific term I need information about appears to be: "{user_term}"

IMPORTANT INSTRUCTIONS:
1. If the context contains a numbered definition (e.g., "141. HCFA Admit Type Code:"), reproduce it EXACTLY as it appears in the document.
2. Look for the complete definition block that includes all the structured information (Format, Technical Name, Length, Positions, Definition, etc.).
3. If multiple context excerpts contain parts of the same numbered definition, combine them to provide the complete definition.
4. Preserve the exact formatting, including bullet points, colons, and spacing.
5. If you find a complete numbered definition, present it as the primary answer.
6. If you only find partial information, clearly indicate what's missing.

Based SOLELY on the provided context below, find and present the information for "{user_term}".

Provided Context from the Document:
---
{context}
---

User Question: {original_question}

Response (reproduce the exact numbered definition if found, maintaining all formatting):
"""
                # Pass the identified user_query_term and the original question to the prompt
                final_prompt = prompt_template.format(
                    user_term=user_query_term, 
                    context=context_str, 
                    original_question=user_query, 
                )
                
                print(f"Sending prompt to LLM model: {CHAT_MODEL_NAME}...") 
                llm_response = chat_model.invoke(final_prompt)
                final_answer = llm_response.content.strip()
        
        print(f"LLM raw answer: {final_answer}")

        # Check if the LLM failed to find the block, potentially indicating retrieval issues
        if "could not find" in final_answer.lower() and best_match_found:
             print("Warning: LLM indicated it couldn't find the block, even though a promising chunk was retrieved. Check LLM prompt or chunk integrity.")
        elif "could not find" in final_answer.lower() and not best_match_found:
             print("Info: LLM indicated it couldn't find the block, and no promising chunk was flagged during retrieval.")


        return jsonify({
            "answer": final_answer,
            "retrieved_sources_metadata": retrieved_metadatas # Return metadata of initially retrieved docs
        })

    except Exception as e:
        app.logger.error(f"Error processing chat query: {e}", exc_info=True)
        import traceback
        traceback.print_exc()
        return jsonify({"error": "An internal error occurred. Please check server logs."}), 500

# Add a route handler for '/chat' that redirects to chat_handler_rag for compatibility
@app.route('/chat', methods=['POST'])
def chat_handler_fallback():
    # Just call the main handler for backward compatibility
    return chat_handler_rag()

if __name__ == '__main__':
    print("Attempting to start Flask development server...")
    print(f"GOOGLE_CLOUD_PROJECT as seen by main.py: {GCP_PROJECT_ID}")
    if not GCP_PROJECT_ID :
        print("Reminder: GOOGLE_CLOUD_PROJECT is not set. The application will not be able to connect to Vertex AI.")
    
    app.run(debug=True, host='0.0.0.0', port=int(os.environ.get('PORT', 8081)))